import { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { BookOpen, MessageCircle, HelpCircle, Layers, Volume2, Trophy, ArrowRight, Zap, Upload, Camera, Type, Sparkles, AlertTriangle, Info } from 'lucide-react'
import { useLanguage } from '../lib/LanguageContext'
import { t } from '../lib/i18n'
import Navbar from '../components/Navbar'
import PageUploader from '../components/PageUploader'
import FloatingEduIcons from '../components/FloatingEduIcons'
import ExplanationCard from '../components/ExplanationCard'
import DoubtChat from '../components/DoubtChat'
import QuizCard from '../components/QuizCard'
import Flashcard from '../components/Flashcard'
import AudioPlayer from '../components/AudioPlayer'
import Leaderboard from '../components/Leaderboard'
import { simplifyPage, generateQuiz, generateFlashcards, getMyGamification, getLeaderboard } from '../lib/api'

/* ── Ambient background ── */
function BgOrbs() {
  return (
    <div style={{ position: 'fixed', inset: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 0 }}>
      <motion.div animate={{ scale: [1, 1.15, 1], x: [0, 30, 0], y: [0, -20, 0] }} transition={{ duration: 16, repeat: Infinity, ease: 'easeInOut' }}
        style={{ position: 'absolute', width: 700, height: 700, top: -250, right: -150, borderRadius: '50%', background: 'radial-gradient(circle,rgba(99,102,241,0.14),transparent 70%)', filter: 'blur(60px)' }} />
      <motion.div animate={{ scale: [1, 1.2, 1], x: [0, -20, 0], y: [0, 25, 0] }} transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut', delay: 5 }}
        style={{ position: 'absolute', width: 500, height: 500, bottom: -100, left: '20%', borderRadius: '50%', background: 'radial-gradient(circle,rgba(139,92,246,0.11),transparent 70%)', filter: 'blur(60px)' }} />
      <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut', delay: 3 }}
        style={{ position: 'absolute', width: 400, height: 400, top: '40%', left: -100, borderRadius: '50%', background: 'radial-gradient(circle,rgba(6,182,212,0.09),transparent 70%)', filter: 'blur(60px)' }} />
    </div>
  )
}

/* ── API Key Error Banner ── */
function ApiKeyBanner({ language }) {
  return (
    <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
      style={{ marginBottom: 20, padding: '14px 18px', borderRadius: 16, background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.22)', display: 'flex', alignItems: 'flex-start', gap: 14 }}>
      <motion.div animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 2, repeat: Infinity }} style={{ fontSize: 22, flexShrink: 0 }}>⚠️</motion.div>
      <div>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#f87171', marginBottom: 5, fontFamily: "'Outfit',sans-serif" }}>{t(language, 'api_key_missing')}</div>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', lineHeight: 1.65 }}>
          {t(language, 'api_key_desc1')} <code style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 5, padding: '1px 6px', fontFamily: 'monospace', color: '#f87171' }}>GROQ_API_KEY</code> {t(language, 'in_text') || 'in'} <code style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 5, padding: '1px 6px', fontFamily: 'monospace', color: '#a5b4fc' }}>backend/.env</code> {t(language, 'api_key_desc2')}{' '}
          <a href="https://console.groq.com" target="_blank" rel="noopener noreferrer" style={{ color: '#818cf8', fontWeight: 600, textDecoration: 'none' }}>{t(language, 'api_key_get')}</a>
        </div>
      </div>
    </motion.div>
  )
}

/* ── Grade Mismatch Banner ── */
function GradeBanner({ detectedClass, userClass, language }) {
  const [dismissed, setDismissed] = useState(false)
  if (!detectedClass || !userClass || dismissed) return null

  const detected = parseInt(detectedClass)
  const current = parseInt(userClass)
  if (detected === current) return null

  const isRevisiting = detected < current
  const isAdvanced = detected > current

  // Config per scenario
  const config = isRevisiting ? {
    emoji: '📚',
    color: '#818cf8',
    bg: 'rgba(99,102,241,0.08)',
    border: 'rgba(99,102,241,0.25)',
    tagBg: 'rgba(99,102,241,0.15)',
    tagColor: '#a5b4fc',
    tagBorder: 'rgba(99,102,241,0.3)',
    tag: `Class ${detected} Content`,
    title: `Revisiting Class ${detected} — Great idea! 💪`,
    desc: `This looks like Class ${detected} content. Revisiting earlier concepts builds a stronger foundation for your Class ${current} studies. Let's understand this thoroughly!`,
    tip: `Tip: Strong basics from Class ${detected} will make Class ${current} topics much easier.`,
  } : {
    emoji: '🚀',
    color: '#06b6d4',
    bg: 'rgba(6,182,212,0.08)',
    border: 'rgba(6,182,212,0.25)',
    tagBg: 'rgba(6,182,212,0.15)',
    tagColor: '#67e8f9',
    tagBorder: 'rgba(6,182,212,0.3)',
    tag: `Class ${detected} Content`,
    title: `Getting ahead to Class ${detected}! 🌟`,
    desc: `This looks like Class ${detected} content — you're exploring beyond your Class ${current} syllabus! The explanation will be tailored to your Class ${current} level so it's easy to understand.`,
    tip: `Tip: Exploring advanced topics early gives you a head start in future classes.`,
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8, scale: 0.97 }}
      style={{
        marginBottom: 20,
        borderRadius: 18,
        background: config.bg,
        border: `1px solid ${config.border}`,
        overflow: 'hidden',
      }}
    >
      {/* Top strip */}
      <div style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: 26, flexShrink: 0 }}>{config.emoji}</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: '#f0eeff', fontFamily: "'Outfit', sans-serif" }}>
                {config.title}
              </span>
              <span style={{
                fontSize: 11, fontWeight: 700, color: config.tagColor,
                background: config.tagBg, border: `1px solid ${config.tagBorder}`,
                borderRadius: 99, padding: '2px 10px', letterSpacing: '0.04em',
              }}>
                {config.tag}
              </span>
            </div>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', margin: 0, lineHeight: 1.6 }}>
              {config.desc}
            </p>
          </div>
        </div>
        <button
          onClick={() => setDismissed(true)}
          style={{ background: 'transparent', border: 'none', color: 'rgba(255,255,255,0.25)', cursor: 'pointer', fontSize: 18, padding: '4px 8px', flexShrink: 0, lineHeight: 1 }}
          title="Dismiss"
        >✕</button>
      </div>

      {/* Tip footer */}
      <div style={{
        padding: '8px 20px',
        background: 'rgba(0,0,0,0.12)',
        borderTop: `1px solid ${config.border}`,
        fontSize: 12,
        color: config.tagColor,
        fontWeight: 600,
        display: 'flex',
        alignItems: 'center',
        gap: 8,
      }}>
        <span>💡</span>
        {config.tip}
      </div>
    </motion.div>
  )
}

/* ── Empty state ── */
function EmptyState({ language, onAction }) {
  const actions = [
    { key: 'upload_pdf', color: '#818cf8', icon: Upload, actionId: 'pdf' },
    { key: 'photo', color: '#c4b5fd', icon: Camera, actionId: 'image' },
    { key: 'webcam', color: '#67e8f9', icon: Camera, actionId: 'webcam' },
    { key: 'paste_text', color: '#6ee7b7', icon: Type, actionId: 'text' },
  ]
  const tips = [
    { icon: '📄', key: 'tip_pdf' },
    { icon: '📷', key: 'tip_photo' },
    { icon: '🌐', key: 'tip_lang' },
    { icon: '🏆', key: 'tip_xp' },
  ]
  const tipTexts = {
    tip_pdf: t(language, 'tip_pdf'),
    tip_photo: t(language, 'tip_photo'),
    tip_lang: t(language, 'tip_lang'),
    tip_xp: t(language, 'tip_xp'),
  }
  const [tip, setTip] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setTip(i => (i + 1) % tips.length), 3200)
    return () => clearInterval(id)
  }, [])

  return (
    <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
      style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 440, gap: 30, textAlign: 'center' }}>
      <div style={{ position: 'relative', width: 140, height: 140 }}>
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 22, repeat: Infinity, ease: 'linear' }}
          style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '1.5px dashed rgba(99,102,241,0.2)' }} />
        <motion.div animate={{ rotate: -360 }} transition={{ duration: 14, repeat: Infinity, ease: 'linear' }}
          style={{ position: 'absolute', inset: 18, borderRadius: '50%', border: '1px dashed rgba(139,92,246,0.15)' }} />
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          style={{ position: 'absolute', inset: 0, borderRadius: '50%' }}>
          <div style={{ position: 'absolute', top: 0, left: '50%', marginLeft: -5, width: 10, height: 10, borderRadius: '50%', background: '#818cf8', boxShadow: '0 0 8px #818cf8' }} />
        </motion.div>
        <motion.div
          animate={{ boxShadow: ['0 0 0 rgba(99,102,241,0)', '0 0 40px rgba(99,102,241,0.45)', '0 0 0 rgba(99,102,241,0)'] }}
          transition={{ duration: 3, repeat: Infinity }}
          style={{ position: 'absolute', inset: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <BookOpen size={36} color="#fff" />
        </motion.div>
      </div>
      <div>
        <h2 style={{ fontFamily: "'Outfit',sans-serif", fontWeight: 800, fontSize: 24, marginBottom: 10, letterSpacing: '-0.4px' }}>{t(language, 'add_page')}</h2>
        <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.35)', maxWidth: 340, lineHeight: 1.75 }}>{t(language, 'upload_first_desc')}</p>
      </div>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', justifyContent: 'center' }}>
        {actions.map(({ key, color, icon: Icon, actionId }) => (
          <motion.button key={actionId} whileHover={{ scale: 1.07, y: -3, boxShadow: `0 10px 32px ${color}28` }} whileTap={{ scale: 0.95 }}
            onClick={() => onAction(actionId)}
            style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '11px 20px', borderRadius: 14, background: `${color}12`, border: `1px solid ${color}28`, color, fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: "'Outfit',sans-serif", transition: 'all 0.2s' }}>
            <Icon size={14} />{t(language, key)}
          </motion.button>
        ))}
      </div>
      <AnimatePresence mode="wait">
        <motion.div key={tip} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
          style={{ display: 'inline-flex', alignItems: 'center', gap: 12, padding: '11px 20px', borderRadius: 100, background: 'rgba(99,102,241,0.06)', border: '1px solid rgba(99,102,241,0.14)', fontSize: 13, color: 'rgba(255,255,255,0.45)', maxWidth: 380 }}>
          <span style={{ fontSize: 18 }}>{tips[tip].icon}</span>
          {tipTexts[tips[tip].key]}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  )
}

/* ── Need content placeholder ── */
function NeedContent({ emoji, title, desc }) {
  const { language } = useLanguage()
  return (
    <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
      style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 340, gap: 16, textAlign: 'center', background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 20, padding: 48 }}>
      <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 3, repeat: Infinity }} style={{ fontSize: 52 }}>{emoji}</motion.div>
      <div style={{ fontSize: 18, fontWeight: 700, fontFamily: "'Outfit',sans-serif" }}>{title}</div>
      <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.35)', maxWidth: 300, lineHeight: 1.65 }}>{desc}</div>
      <div style={{ fontSize: 12, color: '#818cf8', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
        <ArrowRight size={12} /> {t(language, 'go_to_study_tab')}
      </div>
    </motion.div>
  )
}

/* ── Loading spinner ── */
function LoadingCard({ language }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(99,102,241,0.1)', borderRadius: 20, padding: '44px 36px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20 }}>
      <div style={{ position: 'relative', width: 60, height: 60 }}>
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1.2, repeat: Infinity, ease: 'linear' }}
          style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid rgba(99,102,241,0.12)', borderTopColor: '#818cf8' }} />
        <motion.div animate={{ rotate: -360 }} transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          style={{ position: 'absolute', inset: 8, borderRadius: '50%', border: '2px solid rgba(139,92,246,0.2)', borderRightColor: '#c4b5fd' }} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Sparkles size={18} color="#818cf8" />
        </div>
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 16, fontWeight: 700, fontFamily: "'Outfit',sans-serif", marginBottom: 6 }}>{t(language, 'simplify')}…</div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>{t(language, 'please_wait')}</div>
      </div>
      <div style={{ width: 300, height: 3, borderRadius: 3, background: 'rgba(255,255,255,0.04)', overflow: 'hidden' }}>
        <motion.div animate={{ x: ['-100%', '120%'] }} transition={{ duration: 1.4, repeat: Infinity, ease: 'easeInOut' }}
          style={{ width: '45%', height: '100%', background: 'linear-gradient(90deg,transparent,#818cf8,#c4b5fd,transparent)', borderRadius: 3 }} />
      </div>
    </motion.div>
  )
}

/* ══════════════════════════════════════════════════════════════════════════════
   MAIN STUDENT VIEW
══════════════════════════════════════════════════════════════════════════════ */
export default function StudentView() {
  const user = JSON.parse(localStorage.getItem('ncert_user') || '{}')
  const { language, changeLanguage } = useLanguage()
  const userClass = user.class || 10

  const [tab, setTab] = useState('upload')
  const [rawText, setRawText] = useState('')
  const [pageMeta, setPageMeta] = useState({})
  const [explanation, setExplanation] = useState('')
  const [detected, setDetected] = useState({})
  const [quiz, setQuiz] = useState(null)
  const [flashcards, setFlashcards] = useState([])
  const [gamification, setGamification] = useState(null)
  const [leaderboard, setLeaderboard] = useState([])
  const [loadingExplain, setLoadingExplain] = useState(false)
  const [loadingQuiz, setLoadingQuiz] = useState(false)
  const [loadingCards, setLoadingCards] = useState(false)
  const [pointsAnim, setPointsAnim] = useState(null)
  const [uploaderTrigger, setUploaderTrigger] = useState(null)
  const [apiKeyError, setApiKeyError] = useState(false)
  const prevLangRef = useRef(language)

  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get('tab')
    if (p) setTab(p)
  }, [])
  useEffect(() => { getMyGamification().then(setGamification).catch(() => { }) }, [])
  useEffect(() => { if (tab === 'leaderboard') getLeaderboard().then(setLeaderboard).catch(() => { }) }, [tab])

  useEffect(() => {
    if (language !== prevLangRef.current) {
      prevLangRef.current = language
      if (rawText && !loadingExplain) {
        setExplanation(''); setQuiz(null); setFlashcards([])
        fetchExplanation(rawText, language, pageMeta, false)
      }
    }
  }, [language])

  const handleTextExtracted = async (text, meta = {}) => {
    setRawText(text); setPageMeta(meta)
    setExplanation(''); setQuiz(null); setFlashcards([])
    setApiKeyError(false); setTab('upload')
    await fetchExplanation(text, language, meta, false)
  }

  const fetchExplanation = async (text, lang, meta = pageMeta, eli10 = false) => {
    if (!text) return
    setLoadingExplain(true); setApiKeyError(false)
    try {
      const res = await simplifyPage(text, lang, userClass, 'default', eli10, meta.pageId)
      setExplanation(res.simplified); setDetected(res.detected || {})
    } catch (err) {
      const msg = err.message || ''
      if (msg.includes('GROQ_API_KEY') || msg.includes('console.groq.com') || msg.includes('authenticate') || msg.includes('API Key')) {
        setApiKeyError(true); setExplanation('')
      } else {
        setExplanation(`⚠️ ${msg || 'Could not simplify. Please check your Groq API key in backend/.env'}`)
      }
    }
    setLoadingExplain(false)
  }

  const handleClearAll = () => {
    setRawText(''); setExplanation(''); setQuiz(null)
    setFlashcards([]); setDetected({}); setPageMeta({}); setApiKeyError(false)
  }

  const handleTabChange = async (newTab) => {
    setTab(newTab)
    if (newTab === 'quiz' && !quiz && rawText) {
      setLoadingQuiz(true)
      const fetchQuiz = async () => {
        try { 
          const r = await generateQuiz(rawText, userClass, language, pageMeta.pageId, pageMeta.docId);
          if (r.status === 'processing') {
            setTimeout(fetchQuiz, 3000);
          } else {
            setQuiz(r.quiz); 
            setLoadingQuiz(false);
          }
        } catch (err) { 
          setQuiz({ error: err.message || 'Failed to generate quiz' }); 
          setLoadingQuiz(false); 
        }
      }
      fetchQuiz();
    }
    if (newTab === 'flashcards' && !flashcards.length && rawText) {
      setLoadingCards(true)
      const fetchCards = async () => {
        try { 
          const r = await generateFlashcards(rawText, userClass, language, pageMeta.pageId, pageMeta.docId);
          if (r.status === 'processing') {
            setTimeout(fetchCards, 3000);
          } else {
            setFlashcards(r.flashcards); 
            setLoadingCards(false);
          }
        } catch (err) { 
          setFlashcards([{ error: err.message || 'Failed to generate flashcards' }]); 
          setLoadingCards(false); 
        }
      }
      fetchCards();
    }
  }

  const handlePointsAwarded = async (g) => {
    setPointsAnim(g); setTimeout(() => setPointsAnim(null), 3500)
    try { const fresh = await getMyGamification(); setGamification(fresh) } catch { }
  }

  const hour = new Date().getHours()
  const greetKey = hour < 12 ? 'good_morning' : hour < 17 ? 'good_afternoon' : 'good_evening'
  const firstName = user.name?.split(' ')[0] || 'Student'

  const detectedClass = detected?.class_level
  const showGradeBanner = detectedClass && parseInt(detectedClass) !== parseInt(userClass)

  return (
    <div className="mesh-grid" style={{ display: 'flex', minHeight: '100vh', color: '#f8f7ff', fontFamily: "'Plus Jakarta Sans',sans-serif" }}>
      <BgOrbs />
      <FloatingEduIcons />
      <Navbar activeTab={tab} onTabChange={handleTabChange} />

      <main style={{ marginLeft: 240, flex: 1, minHeight: '100vh', padding: '40px 48px 120px', position: 'relative', zIndex: 1 }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>

          {/* ── Header ── */}
          {tab !== 'chat' && (
            <motion.div initial={{ opacity: 0, y: -14 }} animate={{ opacity: 1, y: 0 }} style={{ marginBottom: 36 }}>
              <div style={{ fontSize: 10, color: '#9ea4d4', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6, fontWeight: 700 }}>
                {t(language, greetKey)} 👋
              </div>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
                <h1 style={{ fontFamily: "'Outfit',sans-serif", fontWeight: 900, fontSize: 32, letterSpacing: '-0.8px', marginBottom: 10 }}>
                  {t(language, 'hey_user')}{' '}
                  <span style={{ background: 'linear-gradient(90deg,#818cf8,#c4b5fd)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>{firstName}</span>!
                </h1>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap', marginTop: 4 }}>
                <span style={{ fontSize: 12, color: '#9ea4d4', fontWeight: 500 }}>{t(language, 'class_label')} {userClass} · CBSE</span>
                {gamification && (
                  <>
                    <motion.div whileHover={{ scale: 1.05 }}
                      style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'linear-gradient(135deg,rgba(252,211,77,0.12),rgba(245,158,11,0.05))', border: '1px solid rgba(252,211,77,0.22)', borderRadius: 100, padding: '5px 14px' }}>
                      <motion.span animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 2, repeat: Infinity }} style={{ fontSize: 14 }}>⭐</motion.span>
                      <span style={{ fontSize: 12, fontWeight: 800, color: '#fcd34d' }}>{gamification.points?.toLocaleString() || 0}</span>
                      <span style={{ fontSize: 10, color: '#9ea4d4', fontWeight: 500 }}>{t(language, 'xp_points')}</span>
                    </motion.div>
                    <motion.div whileHover={{ scale: 1.05 }}
                      style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'linear-gradient(135deg,rgba(251,146,60,0.12),rgba(239,68,68,0.05))', border: '1px solid rgba(251,146,60,0.22)', borderRadius: 100, padding: '5px 14px' }}>
                      <motion.span animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 1.5, repeat: Infinity }} style={{ fontSize: 14 }}>🔥</motion.span>
                      <span style={{ fontSize: 12, fontWeight: 800, color: '#fb923c' }}>{gamification.streakCount || 0}d</span>
                      <span style={{ fontSize: 10, color: '#9ea4d4', fontWeight: 500 }}>{t(language, 'streak')}</span>
                    </motion.div>
                  </>
                )}
              </div>
            </motion.div>
          )}

          {/* Chat compact header */}
          {tab === 'chat' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, flexWrap: 'wrap', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontFamily: "'Outfit',sans-serif", fontWeight: 900, fontSize: 20, background: 'linear-gradient(90deg,#818cf8,#c4b5fd)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>NCERT AI</span>
                <span style={{ fontSize: 12, color: '#9ea4d4', fontWeight: 500 }}>· {t(language, 'ask_anything')}</span>
              </div>
              {gamification && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#fcd34d' }}>⭐ {gamification.points?.toLocaleString() || 0} XP</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#fb923c' }}>🔥 {gamification.streakCount || 0}d</span>
                </div>
              )}
            </motion.div>
          )}

          {/* ── Points toast ── */}
          <AnimatePresence>
            {pointsAnim && (
              <motion.div initial={{ opacity: 0, y: -24, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, scale: 0.9, y: -10 }}
                style={{ position: 'fixed', top: 24, right: 24, zIndex: 200, background: 'rgba(13,11,30,0.97)', border: '1px solid rgba(99,102,241,0.4)', borderRadius: 18, padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 14, backdropFilter: 'blur(20px)', boxShadow: '0 8px 48px rgba(99,102,241,0.3)' }}>
                <motion.span animate={{ rotate: [0, 20, -10, 0], scale: [1, 1.3, 1] }} transition={{ duration: 0.6 }} style={{ fontSize: 24 }}>🎉</motion.span>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, fontFamily: "'Outfit',sans-serif", color: '#a5b4fc' }}>+{pointsAnim.pointsAwarded} XP!</div>
                  {pointsAnim.newBadge?.length > 0 && (
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>🏅 {t(language, 'badge_text')} {pointsAnim.newBadge[0]}</div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ── Tab content ── */}
          <AnimatePresence mode="wait">

            {tab === 'upload' && (
              <motion.div key="upload" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>

                {/* Uploader */}
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  style={explanation ? { marginBottom: 24 } : { background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 24, padding: '28px 30px', marginBottom: 28 }}>
                  {!explanation && !loadingExplain && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 22 }}>
                      <motion.div animate={{ boxShadow: ['0 0 0 rgba(99,102,241,0)', '0 0 20px rgba(99,102,241,0.45)', '0 0 0 rgba(99,102,241,0)'] }} transition={{ duration: 2.5, repeat: Infinity }}
                        style={{ width: 44, height: 44, borderRadius: 13, background: 'rgba(99,102,241,0.12)', border: '1px solid rgba(99,102,241,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <BookOpen size={20} color="#818cf8" />
                      </motion.div>
                      <div>
                        <div style={{ fontSize: 16, fontWeight: 800, fontFamily: "'Outfit',sans-serif", marginBottom: 4, color: '#f0eeff' }}>{t(language, 'add_page')}</div>
                        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.35)', lineHeight: 1.6 }}>PDF · {t(language, 'photo')} · {t(language, 'webcam')} · {t(language, 'paste_text')}</div>
                      </div>
                    </div>
                  )}
                  <PageUploader
                    onTextExtracted={handleTextExtracted}
                    triggerAction={uploaderTrigger}
                    onTriggerConsumed={() => setUploaderTrigger(null)}
                    isMinimized={!!(explanation || loadingExplain)}
                    onClear={handleClearAll}
                    language={language}
                    classLevel={userClass}
                  />
                </motion.div>

                {/* ── Grade Banner (shown after detection, before explanation) ── */}
                <AnimatePresence>
                  {showGradeBanner && !loadingExplain && (
                    <GradeBanner
                      detectedClass={detectedClass}
                      userClass={userClass}
                      language={language}
                    />
                  )}
                </AnimatePresence>

                {/* API key error */}
                {apiKeyError && <ApiKeyBanner language={language} />}

                {/* Loading */}
                {loadingExplain && <LoadingCard language={language} />}

                {/* Explanation */}
                {explanation && !loadingExplain && (
                  <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}>
                    <ExplanationCard
                      explanation={explanation}
                      detected={detected}
                      isLoading={false}
                      language={language}
                      onRegenerate={(eli10) => fetchExplanation(rawText, language, pageMeta, eli10)}
                      onAudio={explanation ? () => handleTabChange('audio') : undefined}
                    />
                  </motion.div>
                )}

                {/* Empty state */}
                {!rawText && !loadingExplain && !apiKeyError && (
                  <EmptyState language={language} onAction={a => setUploaderTrigger(a)} />
                )}

              </motion.div>
            )}

            {tab === 'chat' && (
              <motion.div key="chat" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                {!rawText && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                    style={{ marginBottom: 12, padding: '11px 16px', borderRadius: 14, background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.16)', fontSize: 13, color: '#fcd34d', display: 'flex', alignItems: 'center', gap: 10 }}>
                    💡 <span>{t(language, 'upload_first')} {t(language, 'for_smarter_answers')}</span>
                  </motion.div>
                )}
                <DoubtChat context={explanation || rawText} language={language} onLanguageChange={changeLanguage} hasContext={!!rawText} />
              </motion.div>
            )}

            {tab === 'quiz' && (
              <motion.div key="quiz" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                {!rawText
                  ? <NeedContent emoji="🎯" title={t(language, 'nav_quiz')} desc={`${t(language, 'upload_first')} ${t(language, 'to_generate_mcqs')}`} />
                  : <QuizCard quiz={quiz} pageId={pageMeta.pageId} userId={user.id} onPointsAwarded={handlePointsAwarded} isLoading={loadingQuiz} />
                }
              </motion.div>
            )}

            {tab === 'flashcards' && (
              <motion.div key="flash" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                {!rawText
                  ? <NeedContent emoji="🃏" title={t(language, 'nav_cards')} desc={`${t(language, 'upload_first')} ${t(language, 'to_generate_flashcards')}`} />
                  : (
                    <div style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 20, padding: 24 }}>
                      <Flashcard cards={flashcards} isLoading={loadingCards} />
                    </div>
                  )
                }
              </motion.div>
            )}

            {tab === 'audio' && (
              <motion.div key="audio" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                {!explanation
                  ? <NeedContent emoji="🔊" title={t(language, 'nav_listen')} desc={`${t(language, 'upload_first')} ${t(language, 'to_enable_audio')}`} />
                  : <AudioPlayer text={explanation} language={language} onLanguageChange={changeLanguage} />
                }
              </motion.div>
            )}

            {tab === 'leaderboard' && (
              <motion.div key="lb" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <Leaderboard entries={leaderboard} currentUserId={user.id} language={language} />
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </main>

      <style>{`
        @media(min-width:769px) and (max-width:1024px){main{margin-left:240px!important;padding:28px 24px 120px!important;}}
        @media(max-width:768px){.bottom-nav{display:flex!important;}main{margin-left:0!important;padding:20px 16px 120px!important;}main>div{max-width:100%!important;}}
      `}</style>
    </div>
  )
}