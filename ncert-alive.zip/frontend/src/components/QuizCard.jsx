import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CheckCircle, XCircle, ChevronRight, Trophy, RotateCcw, Loader2, Sparkles } from 'lucide-react'
import confetti from 'canvas-confetti'
import { submitQuizScore } from '../lib/api'

export default function QuizCard({ quiz, pageId, userId, onPointsAwarded, isLoading }) {
  const [tab, setTab] = useState('mcq')
  const [answers, setAnswers] = useState({})
  const [revealed, setRevealed] = useState({})
  const [fillAnswers, setFillAnswers] = useState({})
  const [fillRevealed, setFillRevealed] = useState({})
  const [submitted, setSubmitted] = useState(false)
  const [score, setScore] = useState(null)
  const [gamification, setGamification] = useState(null)

  if (quiz?.error) {
    return (
      <div style={{ padding: '28px 24px', borderRadius: 20, background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.18)', textAlign: 'center' }}>
        <p style={{ color: '#fca5a5', fontSize: 14, margin: 0, lineHeight: 1.7 }}>⚠️ {quiz.error}</p>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div style={{ background: 'rgba(18,16,35,0.65)', backdropFilter: 'blur(24px)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 24, padding: '40px 36px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 32 }}>
          <Loader2 size={20} style={{ color: '#818cf8', animation: 'spin 1s linear infinite' }} />
          <span style={{ fontSize: 15, color: 'rgba(255,255,255,0.5)', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Generating quiz questions…</span>
        </div>
        {[1, 2, 3].map(i => (
          <div key={i} style={{ marginBottom: 32 }}>
            <div className="shimmer" style={{ height: 16, borderRadius: 8, width: '78%', marginBottom: 16 }} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[1, 2, 3, 4].map(j => <div key={j} className="shimmer" style={{ height: 52, borderRadius: 14 }} />)}
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (!quiz?.mcq?.length && !quiz?.fill_blanks?.length) return null

  const mcqs = quiz.mcq || []
  const fills = quiz.fill_blanks || []
  const oneLiners = quiz.one_liners || []

  const handleMCQAnswer = (qIdx, option) => {
    if (revealed[qIdx]) return
    setAnswers(prev => ({ ...prev, [qIdx]: option }))
    setRevealed(prev => ({ ...prev, [qIdx]: true }))
  }

  const handleSubmit = async () => {
    const correct = mcqs.filter((q, i) => answers[i] === q.answer).length
    setScore({ correct, total: mcqs.length })
    setSubmitted(true)
    if (correct === mcqs.length && mcqs.length > 0) {
      confetti({ particleCount: 140, spread: 90, origin: { y: 0.6 }, colors: ['#6366f1', '#8b5cf6', '#06b6d4', '#10b981', '#fcd34d'] })
    }
    try {
      if (userId && pageId) {
        const res = await submitQuizScore(userId, pageId, correct, mcqs.length)
        setGamification(res.gamification)
        onPointsAwarded?.(res.gamification)
      }
    } catch {}
  }

  const reset = () => {
    setAnswers({}); setRevealed({}); setFillAnswers({}); setFillRevealed({})
    setSubmitted(false); setScore(null); setGamification(null)
  }

  const allTabs = [
    { id: 'mcq', label: 'MCQ', count: mcqs.length, color: '#818cf8' },
    { id: 'fill', label: 'Fill', count: fills.length, color: '#c4b5fd' },
    { id: 'short', label: 'Short', count: oneLiners.length, color: '#67e8f9' },
  ].filter(t => t.count > 0)

  return (
    <div style={{
      background: 'rgba(14,12,27,0.7)',
      backdropFilter: 'blur(24px)',
      border: '1px solid rgba(255,255,255,0.07)',
      borderRadius: 24,
      overflow: 'hidden',
    }}>
      {/* Tab bar */}
      <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.07)', background: 'rgba(255,255,255,0.015)' }}>
        {allTabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{
              flex: 1, padding: '16px 12px', border: 'none', cursor: 'pointer', background: 'transparent',
              fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 13, letterSpacing: '0.02em',
              color: tab === t.id ? t.color : 'rgba(255,255,255,0.3)',
              borderBottom: tab === t.id ? `2px solid ${t.color}` : '2px solid transparent',
              transition: 'all 0.2s',
            }}>
            {t.label} <span style={{ fontSize: 11, opacity: 0.7 }}>({t.count})</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ padding: '32px 28px' }}>

        {/* MCQ Questions */}
        {tab === 'mcq' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 36 }}>
            {mcqs.map((q, i) => (
              <motion.div key={i}
                initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}>

                {/* Question */}
                <div style={{ marginBottom: 18 }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                    <span style={{
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      minWidth: 28, height: 28, borderRadius: 8,
                      background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.3)',
                      fontSize: 12, fontWeight: 800, color: '#818cf8',
                      fontFamily: "'Outfit', sans-serif", flexShrink: 0, marginTop: 2,
                    }}>Q{i + 1}</span>
                    <p style={{
                      fontSize: 15.5, fontWeight: 600, color: '#eeeeff', lineHeight: 1.75,
                      fontFamily: "'Plus Jakarta Sans', sans-serif", margin: 0,
                    }}>{q.question}</p>
                  </div>
                </div>

                {/* Options — single column always for clean look */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginLeft: 40 }}>
                  {q.options.map((opt, j) => {
                    const isSelected = answers[i] === opt
                    const isCorrect = opt === q.answer
                    const show = revealed[i]

                    let bg = 'rgba(255,255,255,0.03)'
                    let border = '1px solid rgba(255,255,255,0.07)'
                    let color = 'rgba(255,255,255,0.7)'

                    if (show && isCorrect) {
                      bg = 'rgba(16,185,129,0.1)'
                      border = '1px solid rgba(16,185,129,0.5)'
                      color = '#6ee7b7'
                    } else if (show && isSelected && !isCorrect) {
                      bg = 'rgba(239,68,68,0.08)'
                      border = '1px solid rgba(239,68,68,0.45)'
                      color = '#fca5a5'
                    }

                    const letter = ['A', 'B', 'C', 'D'][j]

                    return (
                      <motion.button key={j}
                        whileTap={!show ? { scale: 0.985 } : undefined}
                        whileHover={!show ? { borderColor: 'rgba(99,102,241,0.4)', background: 'rgba(99,102,241,0.06)' } : undefined}
                        onClick={() => handleMCQAnswer(i, opt)}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 14,
                          padding: '14px 18px', borderRadius: 14,
                          background: bg, border, cursor: show ? 'default' : 'pointer',
                          textAlign: 'left', transition: 'all 0.2s',
                          animation: (show && isCorrect) ? 'correctPulse 0.5s ease-out' : (show && isSelected && !isCorrect) ? 'wrongShake 0.5s ease-out' : undefined,
                        }}>
                        <span style={{
                          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                          minWidth: 26, height: 26, borderRadius: 7,
                          background: show && isCorrect ? 'rgba(16,185,129,0.2)' : show && isSelected && !isCorrect ? 'rgba(239,68,68,0.2)' : 'rgba(255,255,255,0.06)',
                          fontSize: 11, fontWeight: 800, color: color,
                          fontFamily: "'Outfit', sans-serif", flexShrink: 0,
                          border: `1px solid ${show && isCorrect ? 'rgba(16,185,129,0.4)' : show && isSelected && !isCorrect ? 'rgba(239,68,68,0.4)' : 'rgba(255,255,255,0.08)'}`,
                        }}>{letter}</span>
                        <span style={{ fontSize: 14.5, lineHeight: 1.65, color, fontFamily: "'Plus Jakarta Sans', sans-serif", fontWeight: 500 }}>{opt}</span>
                        {show && isCorrect && <CheckCircle size={16} style={{ color: '#34d399', marginLeft: 'auto', flexShrink: 0 }} />}
                        {show && isSelected && !isCorrect && <XCircle size={16} style={{ color: '#f87171', marginLeft: 'auto', flexShrink: 0 }} />}
                      </motion.button>
                    )
                  })}
                </div>

                {/* Explanation */}
                <AnimatePresence>
                  {revealed[i] && (
                    <motion.div
                      initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
                      style={{
                        marginTop: 14, marginLeft: 40,
                        padding: '14px 18px', borderRadius: 14,
                        background: 'rgba(99,102,241,0.07)', border: '1px solid rgba(99,102,241,0.18)',
                        display: 'flex', alignItems: 'flex-start', gap: 10,
                      }}>
                      <Sparkles size={14} style={{ color: '#818cf8', flexShrink: 0, marginTop: 2 }} />
                      <p style={{ fontSize: 13.5, lineHeight: 1.7, color: 'rgba(255,255,255,0.55)', margin: 0, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                        {q.explanation}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        )}

        {/* Fill in the Blank */}
        {tab === 'fill' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
            {fills.map((q, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 16 }}>
                  <span style={{
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                    minWidth: 28, height: 28, borderRadius: 8,
                    background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.3)',
                    fontSize: 12, fontWeight: 800, color: '#c4b5fd',
                    fontFamily: "'Outfit', sans-serif", flexShrink: 0, marginTop: 2,
                  }}>Q{i + 1}</span>
                  <p style={{ fontSize: 15.5, fontWeight: 600, color: '#eeeeff', lineHeight: 1.75, fontFamily: "'Plus Jakarta Sans', sans-serif", margin: 0 }}>{q.question}</p>
                </div>
                <div style={{ display: 'flex', gap: 12, marginLeft: 40 }}>
                  <input type="text"
                    style={{
                      flex: 1, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: 12, color: '#f8f7ff', padding: '12px 16px',
                      fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 14,
                      outline: 'none', transition: 'all 0.3s ease',
                    }}
                    onFocus={e => { e.target.style.borderColor = '#6366f1'; e.target.style.boxShadow = '0 0 0 3px rgba(99,102,241,0.15)' }}
                    onBlur={e => { e.target.style.borderColor = 'rgba(255,255,255,0.1)'; e.target.style.boxShadow = 'none' }}
                    placeholder="Type your answer…"
                    value={fillAnswers[i] || ''}
                    onChange={e => setFillAnswers(prev => ({ ...prev, [i]: e.target.value }))}
                    disabled={fillRevealed[i]}
                  />
                  <button onClick={() => setFillRevealed(prev => ({ ...prev, [i]: true }))}
                    disabled={fillRevealed[i]}
                    style={{
                      padding: '12px 20px', borderRadius: 12, border: 'none', cursor: 'pointer',
                      background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', color: '#fff',
                      fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 13,
                      whiteSpace: 'nowrap', opacity: fillRevealed[i] ? 0.5 : 1, transition: 'opacity 0.2s',
                    }}>Check</button>
                </div>
                <AnimatePresence>
                  {fillRevealed[i] && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                      style={{
                        marginTop: 14, marginLeft: 40, padding: '14px 18px', borderRadius: 14,
                        background: 'rgba(16,185,129,0.07)', border: '1px solid rgba(16,185,129,0.2)',
                        display: 'flex', alignItems: 'flex-start', gap: 10,
                      }}>
                      <CheckCircle size={14} style={{ color: '#34d399', flexShrink: 0, marginTop: 2 }} />
                      <div>
                        <p style={{ fontSize: 13.5, fontWeight: 700, color: '#6ee7b7', margin: '0 0 4px', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Answer: {q.answer}</p>
                        <p style={{ fontSize: 13, lineHeight: 1.65, color: 'rgba(255,255,255,0.45)', margin: 0, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{q.explanation}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        )}

        {/* Short Answer */}
        {tab === 'short' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {oneLiners.map((q, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                style={{
                  background: 'rgba(6,182,212,0.04)', border: '1px solid rgba(6,182,212,0.12)',
                  borderRadius: 16, padding: '20px 22px',
                }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 14 }}>
                  <span style={{
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                    minWidth: 28, height: 28, borderRadius: 8,
                    background: 'rgba(6,182,212,0.15)', border: '1px solid rgba(6,182,212,0.3)',
                    fontSize: 12, fontWeight: 800, color: '#67e8f9',
                    fontFamily: "'Outfit', sans-serif", flexShrink: 0, marginTop: 2,
                  }}>Q{i + 1}</span>
                  <p style={{ fontSize: 15.5, fontWeight: 600, color: '#eeeeff', lineHeight: 1.75, fontFamily: "'Plus Jakarta Sans', sans-serif", margin: 0 }}>{q.question}</p>
                </div>
                <details style={{ paddingLeft: 40 }}>
                  <summary style={{ fontSize: 13, color: '#818cf8', cursor: 'pointer', fontWeight: 600, fontFamily: "'Plus Jakarta Sans', sans-serif", listStyle: 'none', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <ChevronRight size={14} /> Show Answer
                  </summary>
                  <p style={{ fontSize: 14.5, lineHeight: 1.75, color: '#6ee7b7', marginTop: 12, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{q.answer}</p>
                </details>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Submit / Score footer */}
      {tab === 'mcq' && mcqs.length > 0 && (
        <div style={{ padding: '0 28px 28px', borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: 24 }}>
          <AnimatePresence mode="wait">
            {!submitted ? (
              <motion.button key="submit"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                whileHover={{ scale: 1.02, boxShadow: '0 8px 30px rgba(99,102,241,0.35)' }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSubmit}
                disabled={Object.keys(revealed).length < mcqs.length}
                style={{
                  width: '100%', padding: '16px 24px', borderRadius: 16, border: 'none', cursor: 'pointer',
                  background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                  color: '#fff', fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 15,
                  opacity: Object.keys(revealed).length < mcqs.length ? 0.45 : 1,
                  transition: 'opacity 0.2s, box-shadow 0.2s',
                  boxShadow: '0 4px 20px rgba(99,102,241,0.2)',
                }}>
                Submit Quiz & Earn Points 🎯
              </motion.button>
            ) : (
              <motion.div key="score"
                initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '20px 24px', borderRadius: 18,
                  background: 'linear-gradient(135deg, rgba(99,102,241,0.15), rgba(139,92,246,0.15))',
                  border: '1px solid rgba(99,102,241,0.3)',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <Trophy size={24} style={{ color: '#fcd34d' }} />
                    <div>
                      <div style={{ fontSize: 22, fontWeight: 900, color: '#fff', fontFamily: "'Outfit', sans-serif" }}>{score.correct}/{score.total}</div>
                      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>questions correct</div>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    {gamification && <div style={{ fontSize: 16, fontWeight: 800, color: '#818cf8', fontFamily: "'Outfit', sans-serif" }}>+{gamification.pointsAwarded} XP 🔥</div>}
                    {gamification?.newBadge?.length > 0 && <div style={{ fontSize: 12, color: '#fcd34d', marginTop: 4 }}>🏅 New badge!</div>}
                  </div>
                </div>
                <button onClick={reset}
                  style={{
                    width: '100%', padding: '14px 24px', borderRadius: 14,
                    background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
                    color: 'rgba(255,255,255,0.7)', fontFamily: "'Outfit', sans-serif", fontWeight: 600, fontSize: 14,
                    cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => { e.target.style.background = 'rgba(255,255,255,0.09)' }}
                  onMouseLeave={e => { e.target.style.background = 'rgba(255,255,255,0.05)' }}>
                  <RotateCcw size={15} /> Try Again
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}
