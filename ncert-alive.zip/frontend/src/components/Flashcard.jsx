import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, RotateCcw, Layers } from 'lucide-react'

const TYPE_COLORS = {
  term: { bg: 'rgba(99,102,241,0.15)', text: '#a5b4fc', label: 'Term' },
  formula: { bg: 'rgba(6,182,212,0.15)', text: '#67e8f9', label: 'Formula' },
  concept: { bg: 'rgba(139,92,246,0.15)', text: '#c4b5fd', label: 'Concept' },
  fact: { bg: 'rgba(16,185,129,0.15)', text: '#6ee7b7', label: 'Fact' },
}

export default function Flashcard({ cards = [], isLoading }) {
  const [current, setCurrent] = useState(0)
  const [flipped, setFlipped] = useState(false)
  const [direction, setDirection] = useState(0)

  if (cards?.[0]?.error) {
    return (
      <div style={{ padding: 24, borderRadius: 16, background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', textAlign: 'center' }}>
        <p style={{ color: '#fca5a5', fontSize: 14, margin: 0 }}>⚠️ {cards[0].error}</p>
      </div>
    )
  }

  if (isLoading) {

    return (
      <div className="space-y-4">
        <div className="shimmer rounded-2xl" style={{ height: 220 }} />
        <div className="flex justify-center gap-2">
          {[1,2,3,4].map(i => <div key={i} className="shimmer w-2 h-2 rounded-full" />)}
        </div>
      </div>
    )
  }

  if (!cards.length) return null

  const card = cards[current]
  const typeStyle = TYPE_COLORS[card.type] || TYPE_COLORS.concept

  const goNext = () => {
    if (current >= cards.length - 1) return
    setFlipped(false); setDirection(1)
    setTimeout(() => setCurrent(c => c + 1), 150)
  }

  const goPrev = () => {
    if (current <= 0) return
    setFlipped(false); setDirection(-1)
    setTimeout(() => setCurrent(c => c - 1), 150)
  }

  return (
    <div className="space-y-4">
      {/* Card count */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <Layers size={14} className="text-indigo-400" />
          <span className="text-sm font-semibold text-gray-300">{current + 1} / {cards.length}</span>
        </div>
        <span className="badge" style={{ background: typeStyle.bg, color: typeStyle.text, border: `1px solid ${typeStyle.text}33` }}>
          {card.emoji} {typeStyle.label}
        </span>
      </div>

      {/* 3D Flashcard */}
      <div className="flashcard-scene">
        <AnimatePresence mode="wait">
          <motion.div
            key={current}
            initial={{ opacity: 0, x: direction * 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction * -40 }}
            transition={{ duration: 0.15 }}
            className="w-full h-full"
          >
            <div
              className={`flashcard-card ${flipped ? 'flipped' : ''}`}
              onClick={() => setFlipped(f => !f)}
            >
              {/* Front */}
              <div className="flashcard-face flashcard-front">
                <div className="mb-3 text-3xl">{card.emoji}</div>
                <h3 className="text-base font-bold text-white mb-2 leading-tight" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  {card.front}
                </h3>
                <p className="text-xs text-indigo-400 mt-auto">Tap to reveal →</p>
              </div>
              {/* Back */}
              <div className="flashcard-face flashcard-back">
                <p className="text-sm text-gray-200 leading-relaxed">{card.back}</p>
                <p className="text-xs text-cyan-400 mt-auto">Tap to flip back ←</p>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <motion.button whileTap={{ scale: 0.9 }} onClick={goPrev} disabled={current === 0}
          className="w-10 h-10 rounded-xl flex items-center justify-center text-gray-400 disabled:opacity-30 transition-all border-0 cursor-pointer hover:bg-white/10"
          style={{ background: 'rgba(255,255,255,0.05)' }}>
          <ChevronLeft size={20} />
        </motion.button>

        {/* Dots */}
        <div className="flex gap-1.5 flex-wrap justify-center max-w-xs">
          {cards.map((_, i) => (
            <motion.button key={i} onClick={() => { setFlipped(false); setCurrent(i) }}
              className="rounded-full transition-all border-0 cursor-pointer"
              animate={{ width: i === current ? 20 : 8, height: 8, background: i === current ? '#6366f1' : 'rgba(255,255,255,0.2)' }}
            />
          ))}
        </div>

        <motion.button whileTap={{ scale: 0.9 }} onClick={goNext} disabled={current === cards.length - 1}
          className="w-10 h-10 rounded-xl flex items-center justify-center text-gray-400 disabled:opacity-30 transition-all border-0 cursor-pointer hover:bg-white/10"
          style={{ background: 'rgba(255,255,255,0.05)' }}>
          <ChevronRight size={20} />
        </motion.button>
      </div>

      {/* Reset */}
      <div className="text-center">
        <button onClick={() => { setCurrent(0); setFlipped(false) }}
          className="text-xs text-gray-500 hover:text-gray-300 flex items-center gap-1 mx-auto border-0 cursor-pointer transition-all"
          style={{ background: 'transparent' }}>
          <RotateCcw size={11} /> Start over
        </button>
      </div>
    </div>
  )
}
