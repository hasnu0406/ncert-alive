import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Bot, User, Trash2, Sparkles } from 'lucide-react'
import LanguageSelector from './LanguageSelector'
import { askDoubt } from '../lib/api'
import { t } from '../lib/i18n'

const SUGGESTIONS = [
  { icon: '✨', text: 'Explain this in the simplest way possible' },
  { icon: '🇮🇳', text: 'Give me a real-life Indian example' },
  { icon: '📝', text: 'What are the key points for my exam?' },
  { icon: '🔍', text: 'Why is this concept important?' },
]

function formatChatMessage(text) {
  if (!text) return null
  const paragraphs = text.split(/\n\n+/)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {paragraphs.map((para, idx) => {
        const lines = para.split('\n')
        const isList = lines.length > 1 && lines.every(line =>
          line.trim().startsWith('-') || line.trim().startsWith('*') || /^\d+\./.test(line.trim())
        )

        if (isList) {
          return (
            <ul key={idx} style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {lines.map((line, lIdx) => {
                const cleanLine = line.replace(/^[-*\u2022]\s*|^\d+\.\s*/, '').trim()
                const boldParts = cleanLine.split(/(\*\*.*?\*\*)/g)
                return (
                  <li key={lIdx} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 15, lineHeight: 1.85, color: 'rgba(255,255,255,0.88)' }}>
                    <span style={{ color: '#818cf8', fontWeight: 900, fontSize: 18, lineHeight: 1.2, flexShrink: 0, marginTop: 1 }}>•</span>
                    <span>
                      {boldParts.map((part, pIdx) => {
                        if (part.startsWith('**') && part.endsWith('**')) {
                          return <strong key={pIdx} style={{ color: '#a5b4fc', fontWeight: 700 }}>{part.slice(2, -2)}</strong>
                        }
                        return part
                      })}
                    </span>
                  </li>
                )
              })}
            </ul>
          )
        }

        const boldParts = para.split(/(\*\*.*?\*\*)/g)
        return (
          <p key={idx} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 15, lineHeight: 1.9, color: 'rgba(255,255,255,0.88)', margin: 0 }}>
            {boldParts.map((part, pIdx) => {
              if (part.startsWith('**') && part.endsWith('**')) {
                return <strong key={pIdx} style={{ color: '#a5b4fc', fontWeight: 700 }}>{part.slice(2, -2)}</strong>
              }
              return part
            })}
          </p>
        )
      })}
    </div>
  )
}

export default function DoubtChat({ context = '', language, onLanguageChange }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [sessionId, setSessionId] = useState(null)
  const bottomRef = useRef()

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  const sendMessage = async (question) => {
    const q = question || input.trim()
    if (!q || loading) return
    setInput('')
    setMessages(prev => [...prev, { role: 'user', content: q, id: Date.now() }])
    setLoading(true)
    try {
      const res = await askDoubt(q, context, language, sessionId)
      setSessionId(res.session_id)
      setMessages(prev => [...prev, { role: 'assistant', content: res.answer, id: Date.now() + 1 }])
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: '⚠️ Could not get a response. Please check your connection.', id: Date.now() + 1, error: true }])
    }
    setLoading(false)
  }

  const handleKeyDown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } }
  const clearChat = () => { setMessages([]); setSessionId(null) }

  return (
    <div style={{
      background: 'rgba(12,10,24,0.72)',
      backdropFilter: 'blur(28px)',
      border: '1px solid rgba(255,255,255,0.07)',
      borderRadius: 24,
      display: 'flex',
      flexDirection: 'column',
      height: 'calc(100vh - 180px)',
      minHeight: 480,
      overflow: 'hidden',
    }}>

      {/* ── HEADER ── */}
      <div style={{
        padding: '18px 24px',
        borderBottom: '1px solid rgba(255,255,255,0.07)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap',
        background: 'rgba(255,255,255,0.015)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{
            width: 44, height: 44, borderRadius: 14, flexShrink: 0,
            background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 16px rgba(99,102,241,0.35)',
            animation: 'pulse 3s ease-in-out infinite',
          }}>
            <Bot size={20} color="#fff" />
          </div>
          <div>
            <div style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, fontSize: 16, color: '#f0eeff', marginBottom: 3 }}>NCERT AI</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, color: '#4ade80', fontWeight: 600 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#4ade80', display: 'inline-block', animation: 'ping 1.5s cubic-bezier(0,0,0.2,1) infinite' }} />
              Online
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <LanguageSelector value={language} onChange={onLanguageChange} compact />
          {messages.length > 0 && (
            <motion.button whileTap={{ scale: 0.9 }} onClick={clearChat}
              style={{
                width: 36, height: 36, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.15)',
                color: 'rgba(239,68,68,0.6)', cursor: 'pointer', transition: 'all 0.2s',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = 'rgba(239,68,68,0.15)'; e.currentTarget.style.color = '#f87171' }}
              onMouseLeave={e => { e.currentTarget.style.background = 'rgba(239,68,68,0.06)'; e.currentTarget.style.color = 'rgba(239,68,68,0.6)' }}>
              <Trash2 size={15} />
            </motion.button>
          )}
        </div>
      </div>

      {/* ── MESSAGES ── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '32px 32px' }}>
        <div style={{ maxWidth: '760px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 32 }}>

          {/* Empty state */}
          {messages.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingTop: 32, paddingBottom: 16, gap: 28 }}
            >
              {/* Bot avatar */}
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
                style={{
                  width: 88, height: 88, borderRadius: 26,
                  background: 'linear-gradient(135deg, rgba(99,102,241,0.18), rgba(139,92,246,0.18))',
                  border: '1px solid rgba(99,102,241,0.35)',
                  boxShadow: '0 0 40px rgba(99,102,241,0.18)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                <Bot size={38} color="#818cf8" />
              </motion.div>

              {/* Greeting text */}
              <div style={{ textAlign: 'center' }}>
                <p style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, fontSize: 22, color: '#f0eeff', margin: '0 0 10px' }}>
                  {t(language, 'ask_me_anything')}
                </p>
                <p style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 14.5, lineHeight: 1.75, color: 'rgba(255,255,255,0.38)', margin: 0, maxWidth: 340 }}>
                  {t(language, 'understand_context')}
                </p>
              </div>

              {/* Suggestion chips — single column for readability */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, width: '100%', maxWidth: 480 }}>
                {SUGGESTIONS.map((s, i) => (
                  <motion.button key={s.text}
                    initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.07 }}
                    whileHover={{ x: 4, borderColor: 'rgba(99,102,241,0.4)', background: 'rgba(99,102,241,0.07)' }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => sendMessage(s.text)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 14,
                      padding: '14px 20px', borderRadius: 16, textAlign: 'left',
                      background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.08)',
                      cursor: 'pointer', transition: 'all 0.2s',
                    }}>
                    <span style={{ fontSize: 18, flexShrink: 0 }}>{s.icon}</span>
                    <span style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 14.5, color: 'rgba(255,255,255,0.65)', fontWeight: 500, lineHeight: 1.5 }}>{s.text}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Messages */}
          <AnimatePresence>
            {messages.map(msg => (
              <motion.div key={msg.id}
                initial={{ opacity: 0, y: 12, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                style={{ display: 'flex', gap: 14, flexDirection: msg.role === 'user' ? 'row-reverse' : 'row', alignItems: 'flex-start' }}
              >
                {/* Avatar */}
                <div style={{
                  width: 36, height: 36, borderRadius: '50%', flexShrink: 0, marginTop: 2,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: msg.role === 'user' ? '#6366f1' : 'linear-gradient(135deg, #7c3aed, #4f46e5)',
                  boxShadow: msg.role === 'user' ? '0 0 14px rgba(99,102,241,0.3)' : '0 0 14px rgba(124,58,237,0.3)',
                }}>
                  {msg.role === 'user' ? <User size={15} color="#fff" /> : <Bot size={15} color="#fff" />}
                </div>

                {/* Bubble */}
                <div style={{
                  maxWidth: '78%',
                  padding: msg.role === 'user' ? '14px 20px' : '18px 24px',
                  borderRadius: msg.role === 'user' ? '20px 4px 20px 20px' : '4px 20px 20px 20px',
                  background: msg.role === 'user'
                    ? 'linear-gradient(135deg, #6366f1, #8b5cf6)'
                    : msg.error ? 'rgba(239,68,68,0.08)' : 'rgba(255,255,255,0.03)',
                  border: msg.role !== 'user' ? `1px solid ${msg.error ? 'rgba(239,68,68,0.2)' : 'rgba(255,255,255,0.08)'}` : undefined,
                  boxShadow: msg.role === 'user' ? '0 6px 24px rgba(99,102,241,0.25)' : undefined,
                }}>
                  {msg.role === 'user' ? (
                    <p style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 15, lineHeight: 1.85, margin: 0, color: '#fff' }}>{msg.content}</p>
                  ) : formatChatMessage(msg.content)}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Typing mascot */}
          <AnimatePresence>
            {loading && (
              <motion.div
                initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 16 }}
                style={{ display: 'flex', alignItems: 'flex-end', gap: 14 }}
              >
                <div style={{ position: 'relative', width: 70, height: 85 }}>
                  <div style={{ position: 'absolute', bottom: -5, left: '50%', transform: 'translateX(-50%)', width: 45, height: 12, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(99,102,241,0.4), transparent 70%)', filter: 'blur(3px)' }} />
                  <svg width="70" height="85" viewBox="0 0 70 85" style={{ display: 'block' }}>
                    <line x1="35" y1="6" x2="35" y2="15" stroke="#818cf8" strokeWidth="2" strokeLinecap="round" />
                    <circle cx="35" cy="5" r="3" fill="#c4b5fd" className="animate-pulse" />
                    <rect x="15" y="15" width="40" height="30" rx="10" fill="url(#miniHeadGrad2)" stroke="rgba(99,102,241,0.5)" strokeWidth="1" />
                    <circle cx="27" cy="28" r="6" fill="#0d0b1e" />
                    <circle cx="27" cy="28" r="2.5" fill="#818cf8" />
                    <circle cx="43" cy="28" r="6" fill="#0d0b1e" />
                    <circle cx="43" cy="28" r="2.5" fill="#818cf8" />
                    <rect x="27" y="38" width="16" height="2" rx="1" fill="rgba(99,102,241,0.6)" />
                    <rect x="31" y="45" width="8" height="6" rx="2" fill="url(#miniBodyGrad2)" />
                    <rect x="12" y="51" width="46" height="26" rx="11" fill="url(#miniBodyGrad2)" stroke="rgba(99,102,241,0.4)" strokeWidth="1" />
                    <rect x="23" y="57" width="24" height="12" rx="4" fill="rgba(99,102,241,0.15)" stroke="rgba(99,102,241,0.3)" strokeWidth="0.8" />
                    <circle cx="35" cy="63" r="3.5" fill="#818cf8" />
                    <rect x="4" y="53" width="7" height="18" rx="3.5" fill="url(#miniBodyGrad2)" />
                    <g style={{ transformOrigin: '59px 56px', animation: 'miniWave 1.2s ease-in-out infinite alternate' }}>
                      <rect x="59" y="47" width="7" height="18" rx="3.5" fill="url(#miniBodyGrad2)" />
                    </g>
                    <defs>
                      <linearGradient id="miniHeadGrad2" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#3730a3" />
                        <stop offset="100%" stopColor="#1e1b4b" />
                      </linearGradient>
                      <linearGradient id="miniBodyGrad2" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#312e81" />
                        <stop offset="100%" stopColor="#1e1b4b" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <style>{`@keyframes miniWave { 0% { transform: rotate(0deg); } 100% { transform: rotate(-35deg); } }`}</style>
                </div>

                <div style={{ position: 'relative', marginBottom: 24 }}>
                  <div style={{ position: 'absolute', bottom: -5, left: 16, width: 10, height: 10, background: 'rgba(18,16,35,0.95)', borderLeft: '1px solid rgba(255,255,255,0.08)', borderBottom: '1px solid rgba(255,255,255,0.08)', transform: 'rotate(45deg)', zIndex: 1 }} />
                  <div style={{ background: 'rgba(18,16,35,0.95)', border: '1px solid rgba(99,102,241,0.3)', borderRadius: '16px 16px 16px 4px', padding: '14px 20px', minWidth: 170, position: 'relative', zIndex: 2 }}>
                    <div style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, fontSize: 10, letterSpacing: '0.12em', color: '#818cf8', marginBottom: 8, textTransform: 'uppercase' }}>NCERT AI</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>is writing</span>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <span className="typing-dot" style={{ background: '#818cf8', width: 6, height: 6, borderRadius: '50%' }} />
                        <span className="typing-dot" style={{ background: '#818cf8', width: 6, height: 6, borderRadius: '50%' }} />
                        <span className="typing-dot" style={{ background: '#818cf8', width: 6, height: 6, borderRadius: '50%' }} />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div ref={bottomRef} />
        </div>
      </div>

      {/* ── INPUT ── */}
      <div style={{ padding: '16px 24px 20px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ maxWidth: '760px', margin: '0 auto' }}>
          <div style={{
            display: 'flex', gap: 12, alignItems: 'flex-end',
            background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.09)',
            borderRadius: 18, padding: '10px 10px 10px 20px',
            transition: 'all 0.3s',
          }}
            onFocus={() => {}}
          >
            <textarea
              rows={1}
              placeholder={t(language, 'type_doubt')}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={loading}
              style={{
                background: 'transparent', border: 'none', outline: 'none',
                color: '#f0eeff', flex: 1, resize: 'none',
                fontFamily: "'Plus Jakarta Sans', sans-serif", fontSize: 15, lineHeight: 1.7,
                minHeight: 42, maxHeight: 140, paddingTop: 8, paddingBottom: 8,
              }}
            />
            <motion.button
              whileHover={{ scale: 1.07, boxShadow: '0 6px 24px rgba(99,102,241,0.45)' }}
              whileTap={{ scale: 0.93 }}
              disabled={!input.trim() || loading}
              onClick={() => sendMessage()}
              style={{
                width: 44, height: 44, borderRadius: 14, flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                border: 'none', cursor: 'pointer',
                boxShadow: '0 4px 18px rgba(99,102,241,0.3)',
                opacity: !input.trim() || loading ? 0.4 : 1,
                transition: 'opacity 0.2s',
              }}
            >
              <Send size={17} color="#fff" />
            </motion.button>
          </div>
          <p style={{ fontSize: 11.5, color: 'rgba(255,255,255,0.2)', marginTop: 8, textAlign: 'center', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            {t(language, 'press_enter')}
          </p>
        </div>
      </div>
    </div>
  )
}
