import { motion } from 'framer-motion'
import { Trophy, Flame } from 'lucide-react'

const RANK_COLORS = ['#fbbf24', '#94a3b8', '#b45309']
const RANK_ICONS = ['🥇', '🥈', '🥉']

import { t } from '../lib/i18n'

export default function Leaderboard({ entries = [], currentUserId, language = 'en' }) {
  if (!entries.length) {
    return (
      <div style={{
        background: 'rgba(14,12,27,0.7)', backdropFilter: 'blur(24px)',
        border: '1px solid rgba(255,255,255,0.07)', borderRadius: 24,
        padding: '64px 40px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20,
      }}>
        <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Trophy size={32} style={{ color: '#fbbf24', opacity: 0.5 }} />
        </div>
        <div>
          <p style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: 18, color: '#f8f7ff', marginBottom: 8 }}>{t(language, 'no_rankings_yet') || 'No rankings yet'}</p>
          <p style={{ fontSize: 14, lineHeight: 1.75, color: 'rgba(255,255,255,0.35)', maxWidth: 280, margin: '0 auto', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{t(language, 'complete_quizzes_lb') || 'Complete quizzes to earn XP points and appear on the leaderboard! 🎯'}</p>
        </div>
      </div>
    )
  }

  return (
    <div style={{
      background: 'rgba(14,12,27,0.7)', backdropFilter: 'blur(24px)',
      border: '1px solid rgba(255,255,255,0.07)', borderRadius: 24,
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        padding: '22px 28px', borderBottom: '1px solid rgba(255,255,255,0.07)',
        background: 'linear-gradient(135deg, rgba(251,191,36,0.08), rgba(99,102,241,0.08))',
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <Trophy size={20} style={{ color: '#fbbf24' }} />
        <h3 style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, fontSize: 16, color: '#fff', margin: 0 }}>{t(language, 'top_students') || 'Top Students'}</h3>
        <span style={{
          marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '4px 12px', borderRadius: 100,
          background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.3)',
          fontSize: 11, fontWeight: 700, color: '#fcd34d', fontFamily: "'Outfit', sans-serif",
        }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#fcd34d', display: 'inline-block', animation: 'flicker 1s infinite' }} />
          {t(language, 'live_ranking') || 'Live Ranking'}
        </span>
      </div>

      {/* Entries */}
      <div>
        {entries.map((entry, i) => {
          const isCurrentUser = entry.id === currentUserId
          return (
            <motion.div key={entry._id || i}
              initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.06 }}
              style={{
                display: 'flex', alignItems: 'center', gap: 18,
                padding: '20px 28px',
                borderBottom: i < entries.length - 1 ? '1px solid rgba(255,255,255,0.04)' : 'none',
                background: isCurrentUser ? 'rgba(99,102,241,0.07)' : 'transparent',
                transition: 'background 0.2s',
              }}
              whileHover={{ background: isCurrentUser ? 'rgba(99,102,241,0.1)' : 'rgba(255,255,255,0.02)' }}
            >
              {/* Rank */}
              <div style={{ width: 36, textAlign: 'center', flexShrink: 0 }}>
                {i < 3
                  ? <span style={{ fontSize: 22 }}>{RANK_ICONS[i]}</span>
                  : <span style={{ fontSize: 15, fontWeight: 800, color: 'rgba(255,255,255,0.3)', fontFamily: "'Outfit', sans-serif" }}>#{i + 1}</span>
                }
              </div>

              {/* Avatar */}
              <div style={{
                width: 44, height: 44, borderRadius: '50%', flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, fontWeight: 800, color: '#fff',
                background: i < 3 ? `linear-gradient(135deg, ${RANK_COLORS[i]}, ${RANK_COLORS[i]}88)` : 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                boxShadow: i < 3 ? `0 0 14px ${RANK_COLORS[i]}44` : '0 0 10px rgba(99,102,241,0.3)',
              }}>
                {entry.name?.[0]?.toUpperCase() || '?'}
              </div>

              {/* Name + class */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 15, fontWeight: 700, color: '#fff', fontFamily: "'Plus Jakarta Sans', sans-serif", overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {entry.name}
                  </span>
                  {isCurrentUser && (
                    <span style={{
                      fontSize: 10, fontWeight: 800, padding: '2px 8px', borderRadius: 100,
                      background: 'rgba(6,182,212,0.15)', border: '1px solid rgba(6,182,212,0.3)', color: '#67e8f9',
                      fontFamily: "'Outfit', sans-serif", flexShrink: 0,
                    }}>{t(language, 'you') || 'YOU'}</span>
                  )}
                </div>
                {entry.class && (
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{t(language, 'class_label') || 'Class'} {entry.class}</div>
                )}
              </div>

              {/* Streak + Points */}
              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: '#fff', fontFamily: "'Outfit', sans-serif", marginBottom: 4 }}>
                  {entry.points?.toLocaleString() || 0}
                  <span style={{ fontSize: 11, fontWeight: 500, color: 'rgba(255,255,255,0.3)', marginLeft: 4 }}>XP</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, justifyContent: 'flex-end', color: '#fb923c', fontSize: 12 }}>
                  <span className="flame">🔥</span>
                  <span style={{ fontWeight: 700 }}>{entry.streakCount || 0}d</span>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
