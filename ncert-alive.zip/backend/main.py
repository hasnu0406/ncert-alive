import hashlib
import io
import os
import uuid
from datetime import datetime, timedelta
from typing import Optional

from bson import ObjectId
from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter, HTTPException, Depends, UploadFile, File, Form, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel

from database import users_collection, assignments_collection
from modules.audio import text_to_speech_bytes
from modules.doubt_chat import chat as doubt_chat, clear_session
from modules.flashcards import generate_flashcards
from modules.gamification import award_points, get_leaderboard
from modules.offline_cache import get_cached, save_cache, get_cached_simplified
from modules.progress import log_progress, get_student_progress, get_children_progress
from modules.quiz_generator import generate_quiz
from modules.simplifier import simplify_text, detect_subject

load_dotenv()

# JWT

SECRET_KEY = os.getenv("SECRET_KEY", "ncert_alive_dev_secret_change_me")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

app = FastAPI(title="NCERT Alive API", version="1.0.0", description="AI-powered NCERT study companion")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    exc_str = str(exc)
    # Detect API key / authentication errors
    if (
        "API Key" in exc_str or "api_key" in exc_str.lower()
        or "AuthenticationError" in exc_str
        or "invalid_api_key" in exc_str
        or "OPENROUTER_API_KEY" in exc_str
        or ("401" in exc_str and "openrouter" in exc_str.lower())
    ):
        return JSONResponse(
            status_code=401,
            content={
                "detail": (
                    "⚠️ Could not authenticate with OpenRouter AI. "
                    "Please add your OPENROUTER_API_KEY in backend/.env and restart the backend server. "
                    "Get a free key at: openrouter.ai"
                )
            }
        )
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal Server Error: {exc_str}"}
    )


# ─── Helper functions ───────────────────────────────────────────

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = await users_collection.find_one({"_id": ObjectId(user_id)})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def serialize_user(user: dict) -> dict:
    return {
        "id": str(user["_id"]),
        "name": user["name"],
        "email": user["email"],
        "role": user["role"],
        "class": user.get("class"),
    }

async def simplify_all_pages_background(
    pages_data: list[dict],
    language: str,
    class_level: int,
    subject: str,
    eli10: bool,
):
    import asyncio
    from modules.simplifier import simplify_text, detect_subject
    from modules.offline_cache import get_cached, save_cache, get_cached_simplified

    for p in pages_data:
        page_id = p["page_id"]
        text = p["text"]

        # Check if already simplified in this language
        cached_val = await get_cached_simplified(page_id, language)
        if cached_val:
            continue

        try:
            # Auto-detect subject if default
            page_subject = subject
            detected_class = None
            if page_subject == "default":
                meta = detect_subject(text)
                page_subject = meta.get("subject", "default")
                detected_class = meta.get("class_level")

            simplified = simplify_text(text, language, class_level, page_subject, eli10)

            existing = await get_cached(page_id)
            if existing:
                simplified_map = existing.get("simplifiedText", {})
                simplified_map[language] = simplified
                await save_cache(
                    page_id=page_id,
                    original_text=text,
                    simplified=simplified_map,
                    quiz=existing.get("quiz", {}),
                    flashcards=existing.get("flashcards", []),
                    subject=page_subject,
                    class_level=class_level,
                    detected_class_level=detected_class
                )
            await asyncio.sleep(1.0)
        except Exception as e:
            print(f"[background] Error simplifying page {page_id} in {language}: {e}")


async def simplify_document_in_new_language_background(
    doc_id: str,
    language: str,
    class_level: int,
    subject: str,
    eli10: bool,
):
    import asyncio
    from modules.simplifier import simplify_text
    from modules.offline_cache import get_cached, save_cache
    from database import cached_content_collection

    cursor = cached_content_collection.find({"pageId": {"$regex": f"^{doc_id}-p"}})
    pages_to_simplify = []
    async for doc in cursor:
        page_id = doc["pageId"]
        if "simplifiedText" in doc and doc["simplifiedText"].get(language):
            continue
        pages_to_simplify.append({
            "page_id": page_id,
            "text": doc["originalText"]
        })

    for p in pages_to_simplify:
        try:
            simplified = simplify_text(p["text"], language, class_level, subject, eli10)

            existing = await get_cached(p["page_id"])
            if existing:
                simplified_map = existing.get("simplifiedText", {})
                simplified_map[language] = simplified
                await save_cache(
                    page_id=p["page_id"],
                    original_text=p["text"],
                    simplified=simplified_map,
                    quiz=existing.get("quiz", {}),
                    flashcards=existing.get("flashcards", []),
                    subject=subject,
                    class_level=class_level
                )
            await asyncio.sleep(1.0)
        except Exception as e:
            print(f"[background-lang] Error simplifying page {p['page_id']} in {language}: {e}")


async def generate_doc_assets_background(
    doc_id: str,
    full_text: str,
    class_level: int,
    language: str
):
    from modules.quiz_generator import generate_quiz
    from modules.flashcards import generate_flashcards
    from modules.offline_cache import save_cache, get_cached
    
    try:
        quiz = generate_quiz(full_text, class_level, language, is_full_doc=True)
        flashcards = generate_flashcards(full_text, class_level, language, is_full_doc=True)
        
        existing = await get_cached(doc_id)
        
        await save_cache(
            page_id=doc_id,
            original_text=full_text[:5000],
            simplified=existing.get("simplifiedText", {}) if existing else {},
            quiz=quiz,
            flashcards=flashcards,
            subject=existing.get("subject", "default") if existing else "default",
            class_level=class_level,
            detected_class_level=existing.get("detectedClassLevel") if existing else None
        )
    except Exception as e:
        print(f"[background] Error generating doc assets for {doc_id}: {e}")



# ─── Auth Router ────────────────────────────────────────────────

auth_router = APIRouter(prefix="/auth", tags=["Auth"])

class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str
    role: str = "student"
    class_level: Optional[int] = None
    linked_parent_email: Optional[str] = None

class LoginResponse(BaseModel):
    access_token: str
    token_type: str
    user: dict

@auth_router.post("/register")
async def register(req: RegisterRequest):
    existing = await users_collection.find_one({"email": req.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    linked_parent_id = None
    if req.linked_parent_email:
        parent = await users_collection.find_one({"email": req.linked_parent_email, "role": "parent"})
        if parent:
            linked_parent_id = parent["_id"]

    user_doc = {
        "name": req.name,
        "email": req.email,
        "password_hash": hash_password(req.password),
        "role": req.role,
        "class": req.class_level,
        "linkedParentId": linked_parent_id,
        "createdAt": datetime.utcnow(),
    }
    result = await users_collection.insert_one(user_doc)
    token = create_access_token({"sub": str(result.inserted_id), "role": req.role})
    user_doc["_id"] = result.inserted_id
    return {"access_token": token, "token_type": "bearer", "user": serialize_user(user_doc)}

@auth_router.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await users_collection.find_one({"email": form_data.username})
    if not user or not verify_password(form_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token({"sub": str(user["_id"]), "role": user["role"]})
    return {"access_token": token, "token_type": "bearer", "user": serialize_user(user)}

@auth_router.get("/me")
async def me(current_user=Depends(get_current_user)):
    return serialize_user(current_user)

# ─── Simplify Router ────────────────────────────────────────────

simplify_router = APIRouter(prefix="/simplify", tags=["Simplify"])

class SimplifyRequest(BaseModel):
    text: str
    language: str = "en"
    class_level: int = 10
    subject: str = "default"
    eli10: bool = False
    page_id: Optional[str] = None

@simplify_router.post("")
async def simplify(req: SimplifyRequest, background_tasks: BackgroundTasks):
    page_id = req.page_id or hashlib.md5(req.text[:200].encode()).hexdigest()

    # Cache check
    cached = await get_cached_simplified(page_id, req.language)
    if cached:
        # Trigger background translation for other pages if this page is part of a document
        if page_id and "-p" in page_id:
            parts = page_id.split("-p")
            if len(parts) == 2 and parts[0]:
                doc_id = parts[0]
                background_tasks.add_task(
                    simplify_document_in_new_language_background,
                    doc_id=doc_id,
                    language=req.language,
                    class_level=req.class_level,
                    subject=req.subject,
                    eli10=req.eli10
                )
        cached_doc = await get_cached(page_id)
        meta = {}
        if cached_doc:
            meta = {
                "subject": cached_doc.get("subject", req.subject),
                "class_level": cached_doc.get("detectedClassLevel") or cached_doc.get("classLevel", req.class_level)
            }
        return {"simplified": cached, "from_cache": True, "page_id": page_id, "detected": meta}

    # Auto-detect subject if default
    meta = {}
    detected_class_level = None
    if req.subject == "default":
        meta = detect_subject(req.text)
        detected_class_level = meta.get("class_level")

    subject = meta.get("subject", req.subject)
    # Always use the user's registered class_level — never override with AI-detected class
    class_level = req.class_level

    simplified = simplify_text(req.text, req.language, class_level, subject, req.eli10)

    # Update cache
    existing = await get_cached(page_id)
    if existing:
        simplified_map = existing.get("simplifiedText", {})
        simplified_map[req.language] = simplified
        await save_cache(page_id, req.text, simplified_map, existing.get("quiz", {}),
                         existing.get("flashcards", []), subject, class_level, detected_class_level)
    else:
        await save_cache(page_id, req.text, {req.language: simplified}, {}, [], subject, class_level, detected_class_level)

    # Trigger background translation for other pages if this page is part of a document
    if page_id and "-p" in page_id:
        parts = page_id.split("-p")
        if len(parts) == 2 and parts[0]:
            doc_id = parts[0]
            background_tasks.add_task(
                simplify_document_in_new_language_background,
                doc_id=doc_id,
                language=req.language,
                class_level=class_level,
                subject=subject,
                eli10=req.eli10
            )

    return {
        "simplified": simplified,
        "from_cache": False,
        "page_id": page_id,
        "detected": meta,
    }

@simplify_router.post("/detect")
async def detect(req: SimplifyRequest):
    return detect_subject(req.text)

# ─── Doubt Chat Router ──────────────────────────────────────────

doubt_router = APIRouter(prefix="/doubt", tags=["Doubt Chat"])

class DoubtRequest(BaseModel):
    question: str
    context: str = ""
    language: str = "en"
    session_id: Optional[str] = None

@doubt_router.post("")
async def ask_doubt(req: DoubtRequest):
    session_id = req.session_id or str(uuid.uuid4())
    answer = doubt_chat(session_id, req.question, req.context, req.language)
    return {"answer": answer, "session_id": session_id}

@doubt_router.delete("/{session_id}")
async def clear_doubt_session(session_id: str):
    clear_session(session_id)
    return {"message": "Session cleared"}

# ─── Quiz Router ────────────────────────────────────────────────

quiz_router = APIRouter(prefix="/quiz", tags=["Quiz"])

class QuizRequest(BaseModel):
    text: str = ""
    class_level: int = 10
    language: str = "en"
    page_id: Optional[str] = None
    doc_id: Optional[str] = None

@quiz_router.post("/generate")
async def generate(req: QuizRequest):
    if req.doc_id:
        cached = await get_cached(req.doc_id)
        if cached and cached.get("quiz") and cached["quiz"].get("mcq"):
            return {"quiz": cached["quiz"], "from_cache": True, "page_id": req.doc_id}
        else:
            return {"status": "processing"}

    page_id = req.page_id or hashlib.md5(req.text[:200].encode()).hexdigest()

    # Cache check
    cached = await get_cached(page_id)
    if cached and cached.get("quiz") and cached["quiz"].get("mcq"):
        return {"quiz": cached["quiz"], "from_cache": True}

    quiz = generate_quiz(req.text, req.class_level, req.language)

    # Update cache
    if cached:
        await save_cache(page_id, cached["originalText"],
                         cached.get("simplifiedText", {}), quiz,
                         cached.get("flashcards", []),
                         cached.get("subject", "default"), cached.get("classLevel", req.class_level),
                         cached.get("detectedClassLevel"))

    return {"quiz": quiz, "from_cache": False, "page_id": page_id}

class ScoreRequest(BaseModel):
    user_id: str
    page_id: str
    correct: int
    total: int

@quiz_router.post("/score")
async def submit_score(req: ScoreRequest):
    score_pct = (req.correct / req.total * 100) if req.total > 0 else 0
    action = "quiz_perfect" if req.correct == req.total else "quiz_correct"
    result = await award_points(req.user_id, action, req.correct)
    await log_progress(req.user_id, req.page_id, "completed", score_pct)
    return {"score": score_pct, "gamification": result}

# ─── Flashcard Router ───────────────────────────────────────────

flashcard_router = APIRouter(prefix="/flashcards", tags=["Flashcards"])

class FlashcardRequest(BaseModel):
    text: str = ""
    class_level: int = 10
    language: str = "en"
    page_id: Optional[str] = None
    doc_id: Optional[str] = None

@flashcard_router.post("/generate")
async def generate_fc(req: FlashcardRequest):
    if req.doc_id:
        cached = await get_cached(req.doc_id)
        if cached and cached.get("flashcards"):
            return {"flashcards": cached["flashcards"], "from_cache": True, "page_id": req.doc_id}
        else:
            return {"status": "processing"}

    page_id = req.page_id or hashlib.md5(req.text[:200].encode()).hexdigest()

    cached = await get_cached(page_id)
    if cached and cached.get("flashcards"):
        return {"flashcards": cached["flashcards"], "from_cache": True}

    cards = generate_flashcards(req.text, req.class_level, req.language)

    # Update cache
    if cached:
        await save_cache(page_id, cached["originalText"],
                         cached.get("simplifiedText", {}), cached.get("quiz", {}),
                         cards,
                         cached.get("subject", "default"), cached.get("classLevel", req.class_level),
                         cached.get("detectedClassLevel"))

    return {"flashcards": cards, "from_cache": False, "page_id": page_id}

# ─── Audio Router ───────────────────────────────────────────────

audio_router = APIRouter(prefix="/audio", tags=["Audio"])

class AudioRequest(BaseModel):
    text: str
    language: str = "en"

@audio_router.post("/generate")
async def generate_audio(req: AudioRequest):
    try:
        audio_bytes = text_to_speech_bytes(req.text, req.language)
        return StreamingResponse(
            io.BytesIO(audio_bytes),
            media_type="audio/mpeg",
            headers={"Content-Disposition": "inline; filename=explanation.mp3"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─── Upload Router ──────────────────────────────────────────────

upload_router = APIRouter(prefix="/upload", tags=["Upload"])

@upload_router.post("/pdf")
async def upload_pdf(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    language: str = Form("en"),
    class_level: int = Form(10),
    subject: str = Form("default"),
    eli10: bool = Form(False),
):
    from modules.pdf_reader import extract_pages_from_pdf
    content = await file.read()
    pages = extract_pages_from_pdf(content)
    total_pages = len(pages)
    if total_pages == 0:
        raise HTTPException(status_code=422, detail="No readable text found in this PDF")

    # Generate a unique doc ID
    doc_id = hashlib.md5(content).hexdigest()

    pages_data = []
    full_text_list = []
    for p in pages:
        page_num = p["page_num"]
        page_text = p["text"]
        page_id = f"{doc_id}-p{page_num}"
        pages_data.append({
            "page_num": page_num,
            "page_id": page_id,
            "text": page_text
        })
        full_text_list.append(page_text)

        # Save original text to cache if not exists
        existing = await get_cached(page_id)
        if not existing:
            await save_cache(
                page_id=page_id,
                original_text=page_text,
                simplified={},
                quiz={},
                flashcards=[],
                subject=subject,
                class_level=class_level
            )
            
    full_text = "\n\n".join(full_text_list)

    # Add background task to simplify all pages in the user's selected language
    background_tasks.add_task(
        simplify_all_pages_background,
        pages_data=pages_data,
        language=language,
        class_level=class_level,
        subject=subject,
        eli10=eli10
    )

    # Add background task to generate document-level quiz and flashcards
    background_tasks.add_task(
        generate_doc_assets_background,
        doc_id=doc_id,
        full_text=full_text,
        class_level=class_level,
        language=language
    )

    return {
        "text": pages_data[0]["text"] if pages_data else "",
        "page_num": 1,
        "total_pages": total_pages,
        "doc_id": doc_id,
        "pages": pages_data
    }

@upload_router.post("/image")
async def upload_image(file: UploadFile = File(...)):
    from modules.ocr import extract_text_from_image, get_ocr_engine
    content = await file.read()
    text = extract_text_from_image(content)
    if not text:
        raise HTTPException(status_code=422, detail="Could not extract text from image")
    return {"text": text, "ocr_engine": get_ocr_engine()}

@upload_router.post("/image-base64")
async def upload_image_b64(payload: dict):
    from modules.ocr import extract_text_from_base64
    b64 = payload.get("image_base64", "")
    text = extract_text_from_base64(b64)
    return {"text": text}

# ─── Progress Router ────────────────────────────────────────────

progress_router = APIRouter(prefix="/progress", tags=["Progress"])

class ProgressRequest(BaseModel):
    page_id: str
    status: str = "completed"
    quiz_score: float = 0
    time_spent: int = 0

@progress_router.post("")
async def save_progress(req: ProgressRequest, current_user=Depends(get_current_user)):
    await log_progress(str(current_user["_id"]), req.page_id, req.status, req.quiz_score, req.time_spent)
    pts = await award_points(str(current_user["_id"]), "page_completed")
    return {"message": "Progress saved", "gamification": pts}

@progress_router.get("/me")
async def my_progress(current_user=Depends(get_current_user)):
    return await get_student_progress(str(current_user["_id"]))

@progress_router.get("/children")
async def children_progress(current_user=Depends(get_current_user)):
    if current_user["role"] != "parent":
        raise HTTPException(status_code=403, detail="Only parents can view children progress")
    return await get_children_progress(str(current_user["_id"]))

# ─── Gamification Router ────────────────────────────────────────

gamification_router = APIRouter(prefix="/gamification", tags=["Gamification"])

@gamification_router.get("/me")
async def my_gamification(current_user=Depends(get_current_user)):
    from modules.gamification import get_or_create_gamification
    doc = await get_or_create_gamification(str(current_user["_id"]))
    doc["_id"] = str(doc["_id"])
    doc["userId"] = str(doc["userId"])
    return doc

@gamification_router.get("/leaderboard")
async def leaderboard():
    return await get_leaderboard(10)

# ─── Assignments Router ─────────────────────────────────────────

assignments_router = APIRouter(prefix="/assignments", tags=["Assignments"])

class AssignmentRequest(BaseModel):
    student_id: str
    page_id: str
    description: Optional[str] = None

@assignments_router.post("")
async def create_assignment(req: AssignmentRequest, current_user=Depends(get_current_user)):
    if current_user["role"] != "teacher":
        raise HTTPException(status_code=403, detail="Only teachers can assign content")
    doc = {
        "teacherId": current_user["_id"],
        "studentId": ObjectId(req.student_id),
        "pageId": req.page_id,
        "description": req.description,
        "status": "assigned",
        "assignedDate": datetime.utcnow(),
    }
    result = await assignments_collection.insert_one(doc)
    return {"assignment_id": str(result.inserted_id), "message": "Assignment created"}

@assignments_router.get("/my")
async def my_assignments(current_user=Depends(get_current_user)):
    if current_user["role"] == "student":
        cursor = assignments_collection.find({"studentId": current_user["_id"]})
    else:
        cursor = assignments_collection.find({"teacherId": current_user["_id"]})
    results = []
    async for doc in cursor:
        doc["_id"] = str(doc["_id"])
        doc["teacherId"] = str(doc["teacherId"])
        doc["studentId"] = str(doc["studentId"])
        results.append(doc)
    return results

@assignments_router.get("/students")
async def list_students(current_user=Depends(get_current_user)):
    if current_user["role"] != "teacher":
        raise HTTPException(status_code=403, detail="Only teachers can list students")
    cursor = users_collection.find({"role": "student"})
    students = []
    async for s in cursor:
        students.append({"id": str(s["_id"]), "name": s["name"], "class": s.get("class"), "email": s["email"]})
    return students

# ─── Register all routers ────────────────────────────────────────

app.include_router(auth_router)
app.include_router(simplify_router)
app.include_router(doubt_router)
app.include_router(quiz_router)
app.include_router(flashcard_router)
app.include_router(audio_router)
app.include_router(upload_router)
app.include_router(progress_router)
app.include_router(gamification_router)
app.include_router(assignments_router)

@app.get("/")
async def root():
    return {"message": "NCERT Alive API is running 🚀", "docs": "/docs"}

@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}
