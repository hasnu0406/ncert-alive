from datetime import datetime
from database import cached_content_collection


async def get_cached(page_id: str) -> dict | None:
    return await cached_content_collection.find_one({"pageId": page_id})


async def save_cache(
    page_id: str,
    original_text: str,
    simplified: dict,
    quiz: dict,
    flashcards: list,
    subject: str,
    class_level: int,
    detected_class_level: int | None = None,
) -> None:
    existing = await cached_content_collection.find_one({"pageId": page_id})
    doc = {
        "pageId": page_id,
        "originalText": original_text,
        "simplifiedText": simplified,  # {"en": ..., "hi": ..., etc.}
        "quiz": quiz,
        "flashcards": flashcards,
        "subject": subject,
        "classLevel": class_level,
        "updatedAt": datetime.utcnow(),
    }
    if detected_class_level is not None:
        doc["detectedClassLevel"] = detected_class_level
    elif existing and "detectedClassLevel" in existing:
        doc["detectedClassLevel"] = existing["detectedClassLevel"]

    if existing:
        await cached_content_collection.update_one({"pageId": page_id}, {"$set": doc})
    else:
        doc["createdAt"] = datetime.utcnow()
        await cached_content_collection.insert_one(doc)


async def get_cached_simplified(page_id: str, language: str) -> str | None:
    doc = await get_cached(page_id)
    if doc and "simplifiedText" in doc:
        return doc["simplifiedText"].get(language)
    return None
