import json
from .ai_engine import ask_ai_json

QUIZ_SYSTEM = (
    "You are an expert CBSE exam question setter. Generate quiz questions in valid JSON only. "
    "No markdown fences, no extra text — pure JSON object."
)


def generate_quiz(text: str, class_level: int = 10, language: str = "en", is_full_doc: bool = False) -> dict:
    from .languages import LANGUAGE_NAMES, get_native_script_instruction
    lang_instruction = get_native_script_instruction(language)

    question_counts = "Generate 15 MCQs, 5 fill-in-the-blanks, and 5 one-liner questions covering the entire document comprehensively." if is_full_doc else "Generate 5 MCQs, 3 fill-in-the-blanks, and 3 one-liner questions."
    
    text_to_use = text[:60000] if is_full_doc else text[:4000]

    prompt = f"""
Generate a quiz for Class {class_level} CBSE students based on the text below.
{lang_instruction}

Return a JSON object with this exact structure:
{{
  "mcq": [
    {{
      "question": "...",
      "options": ["A) ...", "B) ...", "C) ...", "D) ..."],
      "answer": "A) ...",
      "explanation": "..."
    }}
  ],
  "fill_blanks": [
    {{
      "question": "The ___ is responsible for ...",
      "answer": "...",
      "explanation": "..."
    }}
  ],
  "one_liners": [
    {{
      "question": "...",
      "answer": "..."
    }}
  ]
}}

{question_counts}

NCERT Content:
\"\"\"{text_to_use}\"\"\"
"""
    raw = ask_ai_json(prompt, system_prompt=QUIZ_SYSTEM)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Attempt to extract JSON from response
        import re
        match = re.search(r'\{.*\}', raw, re.DOTALL)
        if match:
            return json.loads(match.group())
        return {"mcq": [], "fill_blanks": [], "one_liners": [], "error": "Parse failed"}
