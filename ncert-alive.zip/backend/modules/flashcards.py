import json
from .ai_engine import ask_ai_json

FLASHCARD_SYSTEM = (
    "You are an expert at creating concise study flashcards for CBSE students. "
    "Respond with valid JSON only — no markdown, no extra text."
)


def generate_flashcards(text: str, class_level: int = 10, language: str = "en", is_full_doc: bool = False) -> list:
    from .languages import LANGUAGE_NAMES, get_native_script_instruction
    lang_instruction = get_native_script_instruction(language)

    card_count = "Generate 15-25 flashcards covering all the key concepts from across the entire document." if is_full_doc else "Generate 8-12 flashcards covering key terms, formulas, and important facts."
    
    text_to_use = text[:60000] if is_full_doc else text[:4000]

    prompt = f"""
Create study flashcards for Class {class_level} CBSE students from the content below.
{lang_instruction}

Return a JSON object:
{{
  "flashcards": [
    {{
      "id": 1,
      "type": "term|formula|concept|fact",
      "front": "Term or Question",
      "back": "Definition or Answer",
      "emoji": "relevant emoji"
    }}
  ]
}}

{card_count}

NCERT Content:
\"\"\"{text_to_use}\"\"\"
"""
    raw = ask_ai_json(prompt, system_prompt=FLASHCARD_SYSTEM)
    try:
        data = json.loads(raw)
        return data.get("flashcards", [])
    except json.JSONDecodeError:
        import re
        match = re.search(r'\[.*\]', raw, re.DOTALL)
        if match:
            return json.loads(match.group())
        return []
