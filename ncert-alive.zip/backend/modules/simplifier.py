from .ai_engine import ask_ai, ask_ai_json
from .languages import LANGUAGE_NAMES

SUBJECT_SYSTEM_PROMPTS = {
    "science": "You are a professional CBSE Science tutor. Break down complex topics into clear, easy-to-understand explanations with intuitive real-world examples.",
    "math": "You are a professional CBSE Mathematics tutor. Break down every formula step by step. Use clean equations and simple examples.",
    "history": "You are a professional CBSE History tutor. Connect historical events chronologically using a storytelling approach.",
    "geography": "You are a professional CBSE Geography tutor. Explain physical and cultural geography concepts using clear examples.",
    "economics": "You are a professional CBSE Economics tutor. Explain concepts using real-world business and financial scenarios.",
    "default": "You are a professional CBSE tutor. Use simple language and clear, logical examples.",
}


def simplify_text(
    text: str,
    language: str = "en",
    class_level: int = 10,
    subject: str = "default",
    eli10: bool = False,
) -> str:
    lang_name = LANGUAGE_NAMES.get(language, "English")
    system_prompt = SUBJECT_SYSTEM_PROMPTS.get(subject, SUBJECT_SYSTEM_PROMPTS["default"])

    eli10_instruction = (
        "\n\nIMPORTANT: Use the 'Explain Like I'm 10' mode — use the simplest possible words, "
        "very short sentences, and a fun analogy a child would love."
        if eli10
        else ""
    )

    prompt = f"""
You are explaining NCERT textbook content to a Class {class_level} CBSE student.
Respond entirely in {lang_name}.{eli10_instruction}

Rewrite the following NCERT content in a clear, modern, and highly readable way:
1. Use simple, direct, and professional language (avoid silly, forced analogies like cricket, chai, or auto-rickshaws)
2. Use clear, intuitive real-world examples (like gravity pulling an apple, earth orbiting the sun, etc.)
3. Break down any formulas step by step
4. Highlight key terms by using double asterisks (e.g., **Gravity**)
5. Structure the explanation with clear paragraphs separated by blank lines
6. Use plain bullet points starting with - for lists (never use numbers like 1. 2. 3.)
7. End with a "Key Takeaway 🎯" summary in 1-2 sentences

STRICT FORMATTING RULES — follow these exactly:
- NEVER use ## or ### or any markdown headings whatsoever
- NEVER start a heading with # symbols
- For section titles, write them as plain bold text on their own line, e.g. **Introduction** on one line, then a blank line, then the content
- Always put a blank line (empty line) between every paragraph, section, and bullet list
- Always put a blank line before and after every bullet list
- Each bullet point must be on its own line starting with -
- Never run two paragraphs together on the same line

NCERT Content:
\"\"\"
{text}
\"\"\"
"""
    return ask_ai(prompt, system_prompt=system_prompt, max_tokens=1500)


def detect_subject(text: str) -> dict:
    """Auto-detect subject, topic, and class level from NCERT text."""
    prompt = f"""
You are an expert at identifying NCERT textbook content for Indian CBSE curriculum.

Analyze this NCERT textbook excerpt carefully and respond ONLY with a JSON object.

Rules for class_level detection:
- Class 6: Very basic concepts, simple language, introductory topics
- Class 7: Slightly advanced, building on Class 6
- Class 8: Intermediate concepts, more detail
- Class 9: Higher secondary prep, more complex topics (e.g. French Revolution, Gravitation, Polynomials, Democratic Politics)
- Class 10: Board exam level (e.g. Chemical Reactions, Nationalism in India, Arithmetic Progressions, Light)
- Class 11: Senior secondary, advanced topics (e.g. Thermodynamics, Complex Numbers, Modern History, Business Studies)
- Class 12: Highest level CBSE (e.g. Electromagnetic Induction, Integration, Microeconomics, Flamingo)

Look for specific NCERT chapter names, terminology complexity, and content depth to determine the exact class.

Respond ONLY with this JSON (no explanation, no markdown):
{{
  "subject": "science|math|history|geography|economics|english|default",
  "topic": "specific topic name from the text",
  "class_level": <integer between 6 and 12>,
  "confidence": <float between 0.0 and 1.0>
}}

Text to analyze:
\"\"\"{text[:1000]}\"\"\"
"""
    import json
    raw = ask_ai_json(prompt)
    try:
        result = json.loads(raw)
        result['class_level'] = int(result.get('class_level', 10))
        result['class_level'] = max(6, min(12, result['class_level']))
        return result
    except Exception:
        return {"subject": "default", "topic": "Unknown", "class_level": 10, "confidence": 0.5}