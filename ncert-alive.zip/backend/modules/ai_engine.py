import os
from openai import OpenAI, AuthenticationError
from dotenv import load_dotenv

load_dotenv()

_OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
_client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=_OPENROUTER_API_KEY,
)

PRIMARY_MODEL = "meta-llama/llama-3.3-70b-instruct"
FALLBACK_MODEL = "meta-llama/llama-3.3-70b-instruct"

_API_KEY_ERROR_MSG = (
    "Invalid or missing OPENROUTER_API_KEY. "
    "Please set a valid key in backend/.env and restart the server."
)


def _is_auth_error(exc: Exception) -> bool:
    """Return True for any OpenRouter authentication / key error."""
    msg = str(exc).lower()
    return (
        isinstance(exc, AuthenticationError)
        or "invalid_api_key" in msg
        or "invalid api key" in msg
        or "401" in msg
    )


def ask_ai(
    prompt: str,
    system_prompt: str = "You are a friendly, encouraging tutor. Use simple, clear language, universal analogies, and be warm and supportive.",
    use_fallback: bool = False,
    temperature: float = 0.7,
    max_tokens: int = 1500,
) -> str:
    model = FALLBACK_MODEL if use_fallback else PRIMARY_MODEL
    try:
        response = _client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content or ""
    except Exception as e:
        if _is_auth_error(e):
            raise RuntimeError(_API_KEY_ERROR_MSG) from e
        # Auto-fallback to smaller model on rate-limit or other error
        if not use_fallback:
            print(f"[ai_engine] Primary model failed ({e}), falling back to {FALLBACK_MODEL}")
            return ask_ai(prompt, system_prompt, use_fallback=True, temperature=temperature, max_tokens=max_tokens)
        raise RuntimeError(f"OpenRouter API error: {e}") from e


def ask_ai_json(
    prompt: str,
    system_prompt: str = "You are a helpful assistant. Always respond with valid JSON only, no markdown, no explanation.",
    use_fallback: bool = False,
) -> str:
    """Ask OpenRouter and expect a JSON string back."""
    model = FALLBACK_MODEL if use_fallback else PRIMARY_MODEL
    try:
        response = _client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=2000,
            response_format={"type": "json_object"},
        )
        return response.choices[0].message.content or ""
    except Exception as e:
        if _is_auth_error(e):
            raise RuntimeError(_API_KEY_ERROR_MSG) from e
        if not use_fallback:
            return ask_ai_json(prompt, system_prompt, use_fallback=True)
        raise RuntimeError(f"OpenRouter JSON API error: {e}") from e
