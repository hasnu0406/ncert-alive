LANGUAGE_NAMES = {
    "en": "English",
    "hi": "Hindi",
    "ta": "Tamil",
    "te": "Telugu",
    "hinglish": "Hinglish (a natural mix of Hindi and English)",
    "kn": "Kannada",
    "ml": "Malayalam",
    "mr": "Marathi",
    "bn": "Bengali",
    "gu": "Gujarati",
    "pa": "Punjabi",
    "or": "Odia",
    "ur": "Urdu",
    "as": "Assamese",
    "ne": "Nepali",
    "mai": "Maithili",
    "kok": "Konkani",
    "doi": "Dogri",
    "mni": "Manipuri",
    "san": "Sanskrit",
}


def get_native_script_instruction(language: str) -> str:
    lang_name = LANGUAGE_NAMES.get(language, "English")
    if language == "en":
        return "Respond entirely in English."
    elif language == "hinglish":
        return (
            "Respond in Hinglish (a natural mix of Hindi and English written using the Roman/Latin script, "
            "e.g. 'ye cell membrane ek outer layer hai.'). Do NOT use the Devanagari script."
        )
    else:
        return (
            f"You MUST respond entirely in the {lang_name} language.\n"
            f"CRITICAL: Write using the native script/character set of {lang_name} "
            f"(for example, use Devanagari script for Hindi, Kannada script for Kannada, Tamil script for Tamil, Telugu script for Telugu, Bengali script for Bengali, Malayalam script for Malayalam, Marathi script for Marathi, etc.). "
            f"Do NOT write or transliterate the words using English/Latin alphabets (e.g., do not write Hindi or Kannada using Roman characters like 'Paridrishya ek aisi...'). "
            f"Every single word, including headings, explanations, definitions, and questions/answers, must be written in the native script of {lang_name}."
        )

