from datetime import datetime
from bson import ObjectId
from database import users_collection, progress_collection

async def log_progress(user_id: str, page_id: str, status: str, quiz_score: float = 0, time_spent: int = 0):
    existing = await progress_collection.find_one({"userId": ObjectId(user_id), "pageId": page_id})
    doc = {
        "userId": ObjectId(user_id),
        "pageId": page_id,
        "status": status,
        "quizScore": quiz_score,
        "timeSpent": time_spent,
        "date": datetime.utcnow(),
    }
    if existing:
        await progress_collection.update_one(
            {"userId": ObjectId(user_id), "pageId": page_id},
            {"$set": doc}
        )
    else:
        await progress_collection.insert_one(doc)

async def get_student_progress(user_id: str) -> list:
    cursor = progress_collection.find({"userId": ObjectId(user_id)})
    results = []
    async for doc in cursor:
        doc["_id"] = str(doc["_id"])
        doc["userId"] = str(doc["userId"])
        results.append(doc)
    return results

async def get_children_progress(parent_id: str) -> list:
    # Find children linked to this parent
    children_cursor = users_collection.find({"linkedParentId": ObjectId(parent_id)})
    all_progress = []
    async for child in children_cursor:
        child_id = str(child["_id"])
        progress = await get_student_progress(child_id)
        all_progress.append({
            "child": {"id": child_id, "name": child["name"], "class": child.get("class", "")},
            "progress": progress,
        })
    return all_progress
