from .ai_engine import ask_ai

# In-memory session store: {session_id: [{"role": ..., "content": ...}]}
_sessions: dict[str, list] = {}

from .languages import LANGUAGE_NAMES, get_native_script_instruction

SYSTEM_PROMPT = """You are Aarav, a friendly and encouraging CBSE tutor bot for students (Class 6–12).
- Answer doubts clearly, warmly, and without judgment
- Use simple, direct, and professional language (strictly avoid silly, forced analogies like cricket, chai, auto-rickshaws, or festivals)
- Use clear, intuitive, and universal real-world examples (like gravity pulling an apple, magnetism, or earth orbiting the sun)
- Keep answers concise but complete — avoid walls of text
- If a student seems confused, offer to explain differently
- Use emojis occasionally to be friendly 😊
- Respond in the language specified by the user
"""


def get_or_create_session(session_id: str, context: str = "") -> list:
    if session_id not in _sessions:
        _sessions[session_id] = []
        if context:
            _sessions[session_id].append({
                "role": "system",
                "content": f"The student is studying this content:\n\n{context[:1000]}"
            })
    return _sessions[session_id]


def chat(session_id: str, question: str, context: str = "", language: str = "en") -> str:
    history = get_or_create_session(session_id, context)
    lang_instruction = get_native_script_instruction(language)

    system = SYSTEM_PROMPT + f"\n{lang_instruction}"

    # Build messages for OpenRouter
    messages = [{"role": "system", "content": system}]
    # Include last 10 turns of history (excluding system messages)
    convo = [m for m in history if m["role"] != "system"][-10:]
    messages.extend(convo)
    messages.append({"role": "user", "content": question})

    from openai import OpenAI
    import os
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=os.getenv("OPENROUTER_API_KEY", "")
    )
    response = client.chat.completions.create(
        model="meta-llama/llama-3.3-70b-instruct",
        messages=messages,
        temperature=0.7,
        max_tokens=800,
    )
    answer = response.choices[0].message.content

    # Save to history
    history.append({"role": "user", "content": question})
    history.append({"role": "assistant", "content": answer})

    return answer


def clear_session(session_id: str):
    _sessions.pop(session_id, None)
